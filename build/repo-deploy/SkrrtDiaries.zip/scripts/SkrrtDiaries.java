//package scripts;
//
//import org.tribot.api.General;
//import org.tribot.api.input.Mouse;
//import org.tribot.api2007.Game;
//import org.tribot.script.Script;
//import org.tribot.script.ScriptManifest;
//import org.tribot.script.interfaces.Arguments;
//import org.tribot.script.interfaces.Ending;
//import org.tribot.script.interfaces.Painting;
//import org.tribot.script.interfaces.Starting;
//import org.tribot.util.Util;
//import scripts.data.Constants;
//import scripts.data.Profile;
//import scripts.data.Vars;
//import scripts.gui.GUI;
//import scripts.skrrt_api.task.Task;
//import scripts.skrrt_api.task.TaskSet;
//import scripts.skrrt_api.util.antiban.Antiban;
//import scripts.skrrt_api.util.functions.BankCache;
//import scripts.skrrt_api.util.functions.Logging;
//import scripts.skrrt_api.util.functions.Traversing;
//import scripts.skrrt_api.util.numbers.SeedGenerator;
//import scripts.tasks.*;
//import scripts.tasks.quests.*;
//import scripts.tasks.skills.Agility;
//import scripts.tasks.skills.Fishing;
//import scripts.tasks.skills.Thieving;
//import scripts.tasks.steps.*;
//import scripts.utilities.FileUtilities;
//
//import java.awt.*;
//import java.io.File;
//import java.io.IOException;
//import java.net.MalformedURLException;
//import java.net.URL;
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.HashMap;
//
//import static scripts.data.Constants.PROFILE_PATH;
//import static scripts.data.Vars.*;
//
//public class SkrrtDiaries extends Script implements Starting, PaintInfo, Painting, Arguments, Ending {
//
//    @ScriptManifest(name = "SkrrtDiaries", authors = {"SkrrtNick"}, category = "Quests")
//    private URL fxml;
//    private GUI gui;
//    private boolean launchGUI = true;
//    private int i = 0;
//    private final FluffeesPaint SkrrtPaint = new FluffeesPaint(this, FluffeesPaint.PaintLocations.BOTTOM_LEFT_PLAY_SCREEN, new Color[]{new Color(255, 251, 255)}, "Trebuchet MS", new Color[]{new Color(93, 156, 236, 127)},
//            new Color[]{new Color(39, 95, 175)}, 1, false, 5, 3, 0);
//
//
//    @Override
//    public void run() {
//        FileUtilities.createProfileDirectory(Constants.PROFILE_PATH);
//        SeedGenerator seed = new SeedGenerator();
//        Antiban.setPrintDebug(true);
//        while (seed.getPlayerSeed() == 0) {
//            seed.generateRandom();
//            Vars.playerSeed = seed.getPlayerSeed();
//            if ((int) playerSeed * 100 > 200) {
//                Mouse.setSpeed(General.random(130, 200));
//            } else {
//                Mouse.setSpeed((int) (playerSeed * 100));
//            }
//        }
//        if (launchGUI) {
//            try {
//                fxml = new File(Util.getWorkingDirectory() + "\\src\\scripts\\gui\\gui.fxml").toURI().toURL();
//            } catch (MalformedURLException e) {
//                e.printStackTrace();
//            }
//            gui = new GUI(fxml);
//            gui.show();
//            while (gui.isOpen()) {
//                sleep(500);
//            }
//        }
//        TaskSet prep = new TaskSet(new InitialCheck(), new BuyItems(), new HandleDeath());
//        ArrayList<Task> swapTasks = new ArrayList<>();
//        ArrayList<Task> tasks = new ArrayList<>() {{
//            add(new Quiz());
//            add(new Fishing());
//            add(new Agility());
//            add(new Crafting());
//            add(new RuneMysteries());
//            add(new EnterTheAbyss());
//            add(new Thieving());
//            add(new DoricsQuest());
//            add(new PlagueCity());
//            add(new BuyNewspaper());
//            add(new SpinABowl());
//            add(new EnterSoS());
//            add(new ThessaliasStore());
//            add(new AuburyTeleport());
//            add(new StealTea());
//            add(new JumpOverFence());
//        }};
//        ArrayList<Task> loop = new ArrayList<>();
//        Collections.shuffle(tasks);
//
//        while(runningPrep || runningList){
//            while (runningPrep) {
//                Task task = prep.getValidTask();
//                if (task != null) {
//                    status = task.toString();
//                    task.execute();
//                }
//                if (Game.getGameState() == 30 && task == null) {
//                    Logging.debug("Initialisation completed.");
//                    runningList = true;
//                    runningPrep = false;
//                }
//                General.sleep(20,60);
//            }
//            while (runningList) {
//                if (tasks.isEmpty()) {
//                    Logging.debug("List complete, shutting off script");
//                    runningList = false;
//                }
//                for (Task task : tasks) {
//                    while (task.validate()) {
//                        i=0;
//                        status = task.toString();
//                        if(!runningList){
//                            if (shouldWithdrawItems) {
//                                swapTasks.add(task);
//                                prep = new TaskSet(new BankTask(),new BuyItems());
//                                break;
//                            }
//                            if(shouldBuyItems){
//                                swapTasks.add(task);
//                                prep = new TaskSet(new BuyItems());
//                                break;
//                            }
//                        }
//                        task.execute();
//                        General.sleep(2,4);
//                    }
//                    if (!task.validate()) {
//                        Logging.debug("Should buy items:",shouldBuyItems);
//                        Logging.debug("Should withdraw items:",shouldWithdrawItems);
//                        Logging.debug("Invalid task: " + task.toString());
//                        loop.add(task);
//                        General.sleep(2,4);
//                    } else {
//                        Logging.debug("Valid task found: " + task.toString());
//                    }
//                }
//                tasks.clear();
//                tasks.addAll(loop);
//                if(!swapTasks.isEmpty()){
//                    tasks.addAll(swapTasks);
//                    swapTasks.clear();
//                }
//                if(!shouldBuyItems && !shouldWithdrawItems){
//                    i++;
//                    Logging.debug("Task finding attempt: " + i);
//                }
//                if (i >= 3) {
//                    runningList = false;
//                }
//                General.sleep(2,4);
//            }
//
//        }
//
//    }
//
//    @Override
//    public void onStart() {
//        Traversing.setDaxKey(false);
//    }
//
//    @Override
//    public String[] getPaintInfo() {
//        return new String[]{"SkrrtDiaries V1.04 alpha", "Time ran: " + SkrrtPaint.getRuntimeString(), "Status: " + status, "Current Task: " + currentTask};
//    }
//
//
//    @Override
//    public void onPaint(Graphics graphics) {
//        SkrrtPaint.paint(graphics);
//    }
//
//    @Override
//    public void passArguments(HashMap<String, String> hashMap) {
//        String scriptSelect = hashMap.get("custom_input");
//        String clientStarter = hashMap.get("autostart");
//        String input = clientStarter != null ? clientStarter : scriptSelect;
//        String[] settings = input.split(",");
//        if (settings.length > 0) {
//            for (String s : settings) {
//                if (s.contains("settings:")) {
//                    profileName = s.split(":")[1] != null ? s.split(":")[1] : null;
//                }
//            }
//        }
//        if (profileName != null) {
//            if (!profileName.endsWith(".json")) {
//                profileName += ".json";
//            }
//            try {
//                runtimeSettings = FileUtilities.gson.fromJson(new String(FileUtilities.loadFile(new File(Util.getWorkingDirectory().getAbsolutePath() + PROFILE_PATH + "/" + profileName))), Profile.class);
//                launchGUI = false;
//                runningPrep = true;
//            } catch (IOException e) {
//                Logging.debug("Unable to locate profile");
//            }
//        }
//    }
//
//
//    @Override
//    public void onEnd() {
//        Antiban.destroy();
//    }
//}