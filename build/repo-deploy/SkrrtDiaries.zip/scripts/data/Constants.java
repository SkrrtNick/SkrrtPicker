package scripts.data;

import org.tribot.api2007.types.RSArea;
import org.tribot.api2007.types.RSTile;

public class Constants {

    public static final String PROFILE_PATH = "/Skrrt/Diaries/Profiles";

    public static final int VARROCK_DIARY_EASY = 1176;
    public static final int VARROCK_EASY_COMPLETION = 1723;

    //AREAS

    //GNOME AGILITY

    public static final RSArea LOG_TILE = new RSArea(
            new RSTile(2477, 3439, 0),
            new RSTile(2472, 3436, 0));

    public static final RSArea FIRST_NET = new RSArea(
            new RSTile(2470, 3429, 0),
            new RSTile(2477, 3425, 0));

    public static final RSArea SECOND_NET = new RSArea(
            new RSTile(2490, 3418, 0),
            new RSTile(2481, 3426, 0)
    );
    public static final RSArea FIRST_BRANCH = new RSArea(
            new RSTile(2471, 3424, 1),
            new RSTile(2476, 3422, 1)
    );

    public static final RSArea SECOND_BRANCH = new RSArea(
            new RSTile(2483, 3421, 2),
            new RSTile(2488, 3418, 2)
    );

    public static final RSArea CLIMBING_ROPE = new RSArea(
            new RSTile(2472, 3421, 2),
            new RSTile(2477, 3418, 2)
    );

    public static final RSArea TUNNEL = new RSArea(
            new RSTile(2490, 3427, 0),
            new RSTile(2481, 3431, 0)
    );


    //DRAYNOR AGILITY

    public static final RSArea DRAYNOR_START = new RSArea(
            new RSTile(3103, 3281, 0),
            new RSTile(3106, 3277, 0));

    public static final RSArea CRATE_AREA = new RSArea(
            new RSTile(3096, 3256, 3),
            new RSTile(3101, 3261, 3)
    );

    public static final RSArea GAP_AREA = new RSArea(
            new RSTile(3087, 3255, 3),
            new RSTile(3094, 3253, 3)
    );

    public static final RSTile ROUGH_WALL_TILE = new RSTile(3103, 3279, 0);

    public static final RSArea FIRST_TIGHT_ROPE_AREA = new RSArea(
            new RSTile(3102, 3277, 3),
            new RSTile(3097, 3281, 3)
    );

    public static final RSArea SECOND_TIGHT_ROPE_AREA = new RSArea(new RSTile[]{
            new RSTile(3091, 3277, 3),
            new RSTile(3093, 3275, 3),
            new RSTile(3090, 3272, 3),
            new RSTile(3087, 3274, 3),
            new RSTile(3089, 3276, 3)
    });

    public static final RSArea WALL_AREA = new RSArea(
            new RSTile(3088, 3261, 3),
            new RSTile(3087, 3257, 3)
    );

    public static final RSArea NARROW_WALL_AREA = new RSArea(
            new RSTile(3089, 3265, 3),
            new RSTile(3094, 3268, 3)
    );

    //THIEVING
    public static final RSArea MEN_AREA = new RSArea(new RSTile(3092, 3512, 0), new RSTile(3099, 3508, 0));

    //FISHING
    public static final RSArea FISHING_AREA = new RSArea(
            new RSTile[]{
                    new RSTile(2838, 3436, 0),
                    new RSTile(2863, 3430, 0),
                    new RSTile(2862, 3426, 0),
                    new RSTile(2855, 3423, 0),
                    new RSTile(2834, 3432, 0)
            }
    );
    //KUDOS
    public static final int KUDOS_VARBIT = 3637;

    //QUIZ
    public static final int QUIZ_SETTING = 1014;
    public static final int QUIZ_MASTER = 533;

    public static final RSArea ORLANDO_AREA = new RSArea(new RSTile(1756, 4958, 0), new RSTile(1762, 4953, 0));
    public static final RSArea MUSEUM_ROOM1 = new RSArea(new RSTile(1737, 4984, 0), new RSTile(1781, 4976, 0));
    public static final RSArea MUSEUM_ROOM2 = new RSArea(new RSTile(1772, 4969, 0), new RSTile(1785, 4951, 0));
    public static final RSArea MUSEUM_ROOM3 = new RSArea(new RSTile(1748, 4944, 0), new RSTile(1770, 4935, 0));
    public static final RSArea MUSEUM_ROOM4 = new RSArea(new RSTile(1733, 4969, 0), new RSTile(1746, 4951, 0));

    //ITEMS
    public static final int COINS = 995;
    public static final int MARK_OF_GRACE = 11849;
    public static final int COIN_POUCH = 22521;
    public static final int LEATHER = 1741;
    public static final int THREAD = 1734;
    public static final int NEEDLE = 1733;
    public static final int SMALL_FISHING_NET = 303;

    //TELEPORTS
    public static final int[] RING_OF_WEALTH = {11988, 11986, 11984, 11982, 11980};
    public static final int[] AMULET_OF_GLORY = {1706, 1708, 1710, 1712, 11976, 11978};
    public static final int[] NECKLACE_OF_PASSAGE = {21155, 21153, 21151, 21149, 21146};
    public static final int[] SKILLS_NECKLACE = {11111, 11109, 11107, 11105};
    public static final int VARROCK_TELEPORT = 8007;
    public static final int CAMELOT_TELEPORT = 8010;
    public static final int FALADOR_TELEPORT = 8009;
    public static final int ARDOUGNE_TELEPORT = 8011;

    //RUNE MYSTERIES
    public static final int RUNE_MYSTERIES = 63;

    public static final int RESEARCH_PACKAGE = 290;

    public static final RSArea DUKE_AREA = new RSArea(new RSTile(3208, 3224, 1), new RSTile(3212, 3219, 1));
    public static final RSArea AUBURY_AREA = new RSArea(
            new RSTile[]{
                    new RSTile(3252, 3403, 0),
                    new RSTile(3255, 3402, 0),
                    new RSTile(3255, 3400, 0),
                    new RSTile(3251, 3400, 0),
                    new RSTile(3250, 3401, 0)
            }
    );
    public static final RSArea SEDRIDOR_AREA = new RSArea(new RSTile(3098, 9573, 0), new RSTile(3107, 9569, 0));

    //ENTER THE ABYSS
    public static final int ENTER_THE_ABYSS = 492;

    public static final RSArea MAGE_OF_ZAMORAK_AREA = new RSArea(new RSTile(3101, 3564, 0), new RSTile(3112, 3555, 0));

    public static final RSArea MAGE_OF_ZAMORAK_AREA2 = new RSArea(new RSTile(3256, 3388, 0), new RSTile(3263, 3382, 0));

    public static final RSArea WIZARD_CROMPERTY_AREA = new RSArea(new RSTile(2682, 3326, 0), new RSTile(2685, 3322, 0));

    public static final int TELEPORT_FROM_AUBURY = 2315;
    public static final int TELEPORT_FROM_SEDRIDOR = 2314;
    public static final int TELEPORT_FROM_WIZARD_CROMPERTY = 2316;
    public static final int SCRYING_ORB = 5518;

    //MINING
    //DORICS
    public static final RSArea DORIC_AREA = new RSArea(new RSTile(2950, 3452, 0), new RSTile(2953, 3449, 0));

    public static final int DORICS_QUEST = 31;

    public static final int IRON_ORE = 440;
    public static final int COPPER_ORE = 436;
    public static final int CLAY = 434;

    //PLAGUE CITY

    public static final int PLAGUE_CITY = 165;
    public static final int HAS_TRIED_TO_OPEN_GRILL = 1786;

    public static final int DWELLBERRIES = 2126;
    public static final int ROPE = 954;
    public static final int SPADE = 952;
    public static final int BUCKET_OF_WATER = 1929;
    public static final int BUCKET_OF_MILK = 1927;
    public static final int BUCKET_OF_CHOCOLATE_MILK = 1977;
    public static final int WARRANT = 1503;
    public static final int BOOK = 1509;
    public static final int HANGOVER_CURE = 1504;
    public static final int CHOCOLATE_DUST = 1975;
    public static final int SNAPE_GRASS = 231;
    public static final int PICTURE_OF_ELENA = 1510;
    public static final int GAS_MASK = 1506;
    public static final int A_SMALL_KEY = 1507;
    public static final int SPOOKY_STAIRS = 2522;
    public static final int MUD_PATCH = 2532;
    public static final int GRILL = 11422;
    public static final int PIPE = 2542;
    public static final int PLAGUE_DOOR = 37321;
    public static final int DOOR = 2526;
    public static final int BARREL = 2530;
    public static final int STAIRCASE = 15650;

    public static final RSTile MUD_PATCH_TILE = new RSTile(2566, 3332, 0);
    public static final RSTile PIPE_TILE = new RSTile(2514, 9740, 0);
    public static final RSTile EDMOND_UNDERGROUND = new RSTile(2518, 9759, 0);
    public static final RSTile PICTURE_TILE = new RSTile(2576, 3334, 0);
    public static final RSTile JETHICK_TILE = new RSTile(2540, 3305, 0);
    public static final RSTile CLERK_TILE = new RSTile(2528, 3317, 0);
    public static final RSTile BRAVEK_TILE = new RSTile(2534, 3314, 0);
    public static final RSTile ELENA_TILE = new RSTile(2541, 9671, 0);
    public static final RSTile EDMOND_TILE = new RSTile(2568, 3333, 0);
    public static final RSTile ALRENA_TILE = new RSTile(2573, 3333, 0);

    public static final RSArea UNDERGROUND = new RSArea(new RSTile(2521, 9762, 0), new RSTile(2508, 9737, 0));
    public static final RSArea UPSTAIRS_ALRENA_HOUSE = new RSArea(new RSTile(2574, 3335, 1), new RSTile(2579, 3331, 1));
    public static final RSArea WEST_ARDOUGNE = new RSArea(
            new RSTile[]{
                    new RSTile(2465, 3333, 0),
                    new RSTile(2556, 3333, 0),
                    new RSTile(2557, 3266, 0),
                    new RSTile(2512, 3266, 0),
                    new RSTile(2512, 3280, 0),
                    new RSTile(2463, 3282, 0)
            }
    );
    public static final RSArea MARTHAS_HOUSE = new RSArea(new RSTile(2531, 3328, 0), new RSTile(2533, 3333, 0));
    public static final RSArea UPSTAIRS_MARTHAS_HOUSE = new RSArea(new RSTile(2527, 3329, 1), new RSTile(2533, 3333, 1));
    public static final RSArea OUTSIDE_PLAGUE_HOUSE = new RSArea(new RSTile(2532, 3274, 0), new RSTile(2534, 3272, 0));
    public static final RSArea INSIDE_PLAGUE_HOUSE = new RSArea(
            new RSTile[]{
                    new RSTile(2532, 3271, 0),
                    new RSTile(2532, 3268, 0),
                    new RSTile(2541, 3268, 0),
                    new RSTile(2542, 3273, 0)
            }
    );
    public static final RSArea DOWNSTAIRS_PLAGUE_HOUSE = new RSArea(new RSTile(2536, 9673, 0), new RSTile(2539, 9669, 0));
    public static final RSArea PLAGUE_HOUSE_CELL = new RSArea(new RSTile(2542, 9673, 0), new RSTile(2540, 9669, 0));

    //TASKS

    //CATCH TROUT
    public static final RSArea TROUT_AREA = new RSArea(
            new RSTile[]{
                    new RSTile(3101, 3439, 0),
                    new RSTile(3110, 3434, 0),
                    new RSTile(3102, 3422, 0)
            }
    );
    public static final int FLY_FISHING_ROD = 309;
    public static final int FEATHER = 314;

    //TEA STALL
    public static final RSArea TEA_STALL_AREA = new RSArea(new RSTile(3267, 3416, 0), new RSTile(3272, 3410, 0));
    public static final int TEA_STALL = 635;
    public static final int CUP_OF_TEA = 712;

    //LUMBER YARD
    public static final RSArea SAWMILL_OPERATOR_AREA = new RSArea(new RSTile(3300, 3490, 0), new RSTile(3305, 3487, 0));
    public static final RSArea DYING_TREE_AREA = new RSArea(new RSTile(3307, 3497, 0), new RSTile(3310, 3494, 0));
    public static final int PLANK = 960;
    public static final int BRONZE_AXE = 1351;
    public static final int DYING_TREE = 3648;
    public static final int LOG = 1511;

    //EARTH RUNECRAFTING
    public static final RSArea EARTH_RUNE_ALTAR = new RSArea(new RSTile(3303, 3477, 0), new RSTile(3310, 3472, 0));
    public static final int EARTH_TIARA = 5535;
    public static final int PURE_ESSENCE = 7936;

    //SPIN A BOWL
    public static final RSArea POTTERY_AREA = new RSArea(new RSTile(3082, 3410, 0), new RSTile(3086, 3407, 0));
    public static final int SOFT_CLAY = 1761;
    public static final int POTTERY_MASTER = 270;
    public static final int UNFIRED_BOWL = 1791;
    public static final int POTTERS_WHEEL = 14887;
    public static final int POTTER_OVEN = 11601;

    //NEWSPAPER
    public static final RSArea NEWSPAPER_AREA = new RSArea(new RSTile(3213, 3436, 0), new RSTile(3221, 3431, 0));

    //THESSELIA
    public static final RSArea THESSELIA_AREA = new RSArea(new RSTile(3204, 3419, 0), new RSTile(3208, 3413, 0));

    //JUMP OVER FENCE
    public static final RSArea FENCE_AREA = new RSArea(new RSTile(3237, 3337, 0), new RSTile(3243, 3331, 0));
    public static final int FENCE = 16518;

    //STRONGHOLD_OF_SECURITY
    public static final RSArea SOS_AREA = new RSArea(new RSTile(2041, 5244, 0), new RSTile(2046, 5241, 0));

    //IRON
    public static final RSArea VARROCK_EAST_MINE_AREA = new RSArea(new RSTile(3281, 3369, 0), new RSTile(3290, 3360, 0));
    public static final int BRONZE_PICKAXE = 1265;

    //DOG
    public static final RSArea DOG_AREA1 = new RSArea(new RSTile(3165, 3446, 0), new RSTile(3174, 3435, 0));
    public static final RSArea DOG_AREA2 = new RSArea(new RSTile(3196, 3401, 0), new RSTile(3201, 3399, 0));
    public static final RSArea DOG_AREA3 = new RSArea(new RSTile(3234, 3396, 0), new RSTile(3236, 3392, 0));
    public static final RSArea DOG_AREA4 = new RSArea(new RSTile(3261, 3411, 0), new RSTile(3263, 3407, 0));
    public static final RSArea DOG_AREA5 = new RSArea(new RSTile(3274, 3385, 0), new RSTile(3278, 3379, 0));
    public static final int BONES = 526;

}
