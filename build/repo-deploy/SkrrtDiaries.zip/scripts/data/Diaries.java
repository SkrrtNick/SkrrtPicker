package scripts.data;

import org.tribot.api2007.Game;

import java.math.BigInteger;

public enum Diaries {


    THESSELIAS_STORE(0),
    GIVE_DOG_BONE(1),
    AUBURY(2),
    IRON(3),
    PLANK(4),
    STRONGHOLD_OF_SECURITY(5),
    JUMP_OVER_FENCE(6),
    DYING_TREE(7),
    BUYNEWSPAPER(8),

    FIRE_A_BOWL(10),
    HAIG_HELEN(11),
    RUNECRAFT_EARTH_RUNE(12),
    TROUT(13),
    TEA(14);


    private int bit;

    Diaries(int bit) {
        this.bit = bit;
    }

    public boolean isCompleted() {
        return BigInteger.valueOf(Game.getSetting(Constants.VARROCK_DIARY_EASY)).testBit(bit);
    }



}
