package scripts.data;

import lombok.Getter;
import lombok.Setter;

public class Profile {
    @Getter
    @Setter
    public boolean
            shouldJumpFence,
            shouldSos,
            shouldGiveDogBone,
            shouldBuyNewspaper,
            shouldChopTree,
            shouldPlank,
            shouldIron,
            shouldRuneMysteries,
            shouldThesseliasStore,
            shouldStealTea,
            shouldCatchTrout,
            shouldCraftEarthRunes,
            shouldHaigHalen,
            shouldKudos,
            shouldSpinABowl,
            shouldSoftLevelCaps,
            shouldTrainAgility,
            shouldTrainCrafting,
            shouldTrainRunecrafting,
            shouldTrainThieving,
            shouldTrainFishing,
            shouldTrainMining;


}
