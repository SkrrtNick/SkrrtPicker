package scripts.data;



public class Vars {

    public static double playerSeed = 0;
    public static boolean runningPrep = false;
    public static boolean runningList = false;
    public static String status;
    public static String currentTask;
    public static boolean initialCheck = false;
    public static String profileName;
    public static Profile runtimeSettings = null;
    public static boolean shouldBuyItems = false;
    public static boolean shouldWithdrawItems = false;
    public static int gp = 0;

    //TASK RELATED
    public static int requiredLeather = 0;
    public static int actualAgility,goalAgility,actualCrafting,goalCrafting,actualRunecrafting,goalRunecrafting,goalThieving,actualThieving,actualFishing,goalFishing,actualMining,goalMining,kudos;

}




