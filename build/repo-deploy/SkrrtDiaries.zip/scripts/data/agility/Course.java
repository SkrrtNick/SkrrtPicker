package scripts.data.agility;

import lombok.Getter;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api2007.GroundItems;
import org.tribot.api2007.Skills;
import org.tribot.api2007.ext.Filters;
import org.tribot.api2007.types.RSArea;
import org.tribot.api2007.types.RSGroundItem;
import scripts.data.Constants;
import scripts.data.Vars;
import scripts.skrrt_api.util.antiban.Antiban;
import scripts.skrrt_api.util.functions.*;
import scripts.skrrt_api.util.numbers.Reactions;

import java.util.ArrayList;
import java.util.Arrays;

public class Course {
    @Getter
    protected String name;
    @Getter
    protected int stoppingLevel;
    @Getter
    protected RSArea startArea;
    @Getter
    protected Obstacle[] obstacles;
    @Getter
    protected int[] teleport;
    @Getter
    protected boolean canFail;

    public Course(String name, int stoppingLevel, RSArea startArea, boolean canFail, int[] teleport, Obstacle[] obstacles) {
        this.name = name;
        this.stoppingLevel = stoppingLevel;
        this.startArea = startArea;
        this.obstacles = obstacles;
        this.teleport = teleport;
        this.canFail = canFail;
    }

    public void doCourse(){
        while(Skills.SKILLS.AGILITY.getActualLevel() < getStoppingLevel()){
            for (Obstacle o: obstacles){
                Interaction.handleContinue();
                Antiban.generateTrackers((int)Reactions.getAgilitySleep());
                Antiban.timedActions();
                while (!o.doObstacle(o)){
                    Traversing.smartWalk(o.getStartTile());
                    Logging.debug("Something went wrong clicking " + o.getName() + "... Trying again");
                }
                if(hasFallen() && o != obstacles[obstacles.length - 1]){
                    Logging.debug("Oh no! We have fallen.");
                    break;
                }
            }
        }
    }


    public boolean hasFallen(){
        return canFail && !getStartArea().contains(Player07.getPosition()) && Player07.getPlane() == 0;
    }

    public static Course getCurrentCourse(ArrayList<Course> courses){
        for(Course c: courses){
            if(c.stoppingLevel > Skills.getCurrentLevel(Skills.SKILLS.AGILITY)){
                return c;
            }
        } return null;
    }


    public boolean withdrawTeleports(ArrayList<Course> courses){
        for(Course c:courses){
            if(c.stoppingLevel> Skills.getActualLevel(Skills.SKILLS.AGILITY)){
                if(Banking07.withdrawItems(false,1,c.getTeleport())){
                    Timing.waitCondition(()->Inventory07.getCount(teleport) > 0, Reactions.getNormal());
                } else {
                    Banking07.close();
                    Vars.shouldBuyItems = true;
                    return false;
                }
            }
        }
        Banking07.close();
        return true;
    }

}
