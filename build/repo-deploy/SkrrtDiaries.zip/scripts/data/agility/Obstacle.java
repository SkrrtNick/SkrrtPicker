package scripts.data.agility;

import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api2007.GroundItems;
import org.tribot.api2007.ext.Filters;
import org.tribot.api2007.types.RSArea;
import org.tribot.api2007.types.RSGroundItem;
import org.tribot.api2007.types.RSTile;
import scripts.data.Constants;
import scripts.skrrt_api.util.antiban.Antiban;
import scripts.skrrt_api.util.functions.*;
import scripts.skrrt_api.util.numbers.Reactions;

import java.util.Arrays;

public class Obstacle {

    private String name;
    private String action;
    private RSTile startTile;
    private RSArea startArea;

    public Obstacle(String name, String action, RSArea startArea) {
        this.name = name;
        this.action = action;
        this.startArea = startArea;
        this.startTile = startArea.getRandomTile();

    }

    public Obstacle(String name, String action, RSTile startTile) {
        this.name = name;
        this.action = action;
        this.startTile = startTile;
    }

    public boolean doObstacle(Obstacle obstacle) {
        if (obstacle.startTile != null && obstacle.startArea == null) {
            Traversing.smartWalk(obstacle.startTile);
            General.println(Player07.distanceTo(obstacle.startTile) == 0);
            Timing.waitCondition(() -> (Player07.distanceTo(obstacle.startTile) == 0 && !Player07.isMoving()), Reactions.getAgilitySleep());
        } else if (obstacle.startArea != null) {
            Traversing.smartWalk(obstacle.startTile);
            Timing.waitCondition(() -> (getStartArea().contains(Player07.getPosition()) && !Player07.isMoving()), Reactions.getAgilitySleep());
        }
        if (!Player07.isMoving() || getStartArea() != null && getStartArea().contains(Player07.getPosition())) {
            Interaction.handleContinue();
            handleMarkOfGrace();
            General.sleep(Reactions.getNormal());
            if (Interaction.dynamicClickObject(obstacle.name, obstacle.action)) {
                long sleep = Reactions.getAgilitySleep() * 2;
                Antiban.timedActions();
                General.sleep(sleep);
                Logging.debug("Sleep: ",(int)sleep);
                Timing.waitCondition(()->!Player07.isAnimating() && !Player07.isMoving(), sleep);
                General.sleep(Reactions.getNormal());
                Antiban.generateTrackers((int)sleep);
                return true;
            }
        }
        return false;
}

    public String getName() {
        return name;
    }

    public String getAction() {
        return action;
    }

    public RSTile getStartTile() {
        return startTile;
    }

    public RSArea getStartArea() {
        return startArea;
    }
    public void handleMarkOfGrace(){
        int count = Inventory07.getCount(Constants.MARK_OF_GRACE);
        RSGroundItem markOfGrace = Arrays.stream(GroundItems.getAll()).filter(Filters.GroundItems.idEquals(Constants.MARK_OF_GRACE)).findFirst().orElse(null);
        if(markOfGrace != null && Player07.distanceTo(markOfGrace) < 6){
            if(markOfGrace.isClickable() && (!Inventory07.isFull() || Inventory07.getCount(Constants.MARK_OF_GRACE) > 0)){
                Logging.message("Grabbing a Mark of Grace, total count is: " + count);
                markOfGrace.click();
                Timing.waitCondition(()->Inventory07.getCount(Constants.MARK_OF_GRACE) > count, Reactions.getSemiAFK());
            } else {
                markOfGrace.adjustCameraTo();
            }
        }
    }
}
