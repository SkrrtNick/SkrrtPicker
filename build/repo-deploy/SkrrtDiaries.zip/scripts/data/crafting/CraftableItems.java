package scripts.data.crafting;

import org.tribot.api.General;
import org.tribot.api2007.Skills;
import scripts.data.Vars;
import scripts.data.agility.Course;
import scripts.skrrt_api.util.functions.Logging;

import java.util.ArrayList;

public enum CraftableItems {

    LEATHER_GLOVES("Leather gloves",7,13.8),
    LEATHER_BOOTS("Leather boots",9,16.2),
    LEATHER_COWL("Leather cowl",11,18.5),
    LEATHER_VAMBRACES("Leather vambraces",20,22);

    private String name;
    private int level;
    private double xp;

    CraftableItems(String name, int level, double xp) {
        this.name = name;
        this.level = level;
        this.xp = xp;
    }

    public String getName() {
        return name;
    }

    public int getLevel() {
        return level;
    }

    public double getXp() {
        return xp;
    }

    public static CraftableItems getCurrentCraftingItem(){
        CraftableItems temp = null;
        for(CraftableItems c: CraftableItems.values()){
            if(c.level > Skills.getCurrentLevel(Skills.SKILLS.CRAFTING)){
                temp = c;
                return temp;
            }
        } return null;
    }

    public static int getRequiredLeather(int goalLevel) {

        for (int i = 0; i < CraftableItems.values().length; i++) {
            if (Vars.actualCrafting < CraftableItems.values()[i].getLevel() && CraftableItems.values()[i].getLevel() <= goalLevel) {
                Vars.requiredLeather +=(Skills.getXPByLevel(CraftableItems.values()[i].getLevel()) - Skills.getXPByLevel(Vars.actualCrafting)) / (CraftableItems.values()[i].getXp());
            }
        } return Vars.requiredLeather;
    }
}
