package scripts.data.kudos;

import org.tribot.api.General;
import org.tribot.api2007.Interfaces;
import org.tribot.api2007.types.RSArea;
import org.tribot.api2007.types.RSInterface;
import org.tribot.api2007.types.RSVarBit;
import scripts.data.Constants;
import scripts.skrrt_api.util.functions.Logging;
import scripts.skrrt_api.util.functions.Player07;
import scripts.skrrt_api.util.numbers.Reactions;

import java.util.Arrays;
import java.util.List;

public enum Exhibit {

    LIZARD(3675, 24605, Constants.MUSEUM_ROOM1, Arrays.asList("Sunlight.", "The Slayer Masters.", "Three.", "Squamata.", "It becomes sleepy.", "Hair.")),
    BATTLE_TORTOISE(3680, 24606, Constants.MUSEUM_ROOM1, Arrays.asList("Mibbiwocket.", "Vegetables.", "Admiral Bake.", "Hard shell.", "Twenty years.", "Gnomes.")),
    DRAGON(3672, 24607, Constants.MUSEUM_ROOM1, Arrays.asList("Runite.", "Anti dragon-breath shield.", "Unknown.", "Elemental.", "Old battle sites.", "Twelve.")),
    WYVERN(3681, 24608, Constants.MUSEUM_ROOM1, Arrays.asList("Climate change.", "Two.", "Asgarnia.", "Reptiles.", "Dragons.", "Below room temperature.")),
    SNAIL(3674, 24613, Constants.MUSEUM_ROOM2, Arrays.asList("It is resistant to acid.", "Spitting acid.", "Fireproof oil.", "Acid-spitting snail.", "Contracting and stretching.", "An operculum.")),
    SNAKE(3677, 24614, Constants.MUSEUM_ROOM2, Arrays.asList("Stomach acid.", "Tongue.", "Seeing how you smell.", "Constriction.", "Squamata.", "Anywhere.")),
    SEASLUG(3682, 24616, Constants.MUSEUM_ROOM2, Arrays.asList("Nematocysts.", "The researchers keep vanishing.", "Seaweed.", "Defense or display.", "Ardougne.", "They have a hard shell.")),
    MONKEY(3676, 24615, Constants.MUSEUM_ROOM2, Arrays.asList("Simian.", "Harmless.", "Bitternuts.", "Red.", "Seaweed.")),
    KALPHITE_QUEEN(3684, 24618, Constants.MUSEUM_ROOM3, Arrays.asList("Pasha.", "Worker.", "Lamellae.", "Carnivores.", "Scarab beetles.", "Scabaras.")),
    TERRORBIRD(3683, 24617, Constants.MUSEUM_ROOM3, Arrays.asList("Anything.", "Gnomes.", "Eating plants.", "Stones.", "0.", "Four.")),
    PENGUIN(3673, 24612, Constants.MUSEUM_ROOM4, Arrays.asList("Sight.", "Planning.", "A layer of fat.", "Cold.", "Social.", "During breeding.")),
    MOLE(3678, 24611, Constants.MUSEUM_ROOM4, Arrays.asList("Subterranean.", "They dig holes.", "Wyson the Gardener.", "A labour.", "Insects and other invertebrates.", "The Talpidae family.")),
    CAMEL(3679, 24609, Constants.MUSEUM_ROOM4, Arrays.asList("Toxic dung.", "Two.", "Omnivore.", "Annoyed.", "Al Kharid.", "Milk.")),
    LEECH(3685, 24610, Constants.MUSEUM_ROOM4, Arrays.asList("Water.", "'Y'-shaped.", "Apples.", "Environment.", "They attack by jumping.", "It doubles in size."));

    private int varbit;
    private RSArea room;
    private int plaqueID;
    private List<String> options;

    Exhibit(int varbit, int plaqueID, RSArea room, List<String> options) {
        this.varbit = varbit;
        this.plaqueID = plaqueID;
        this.room = room;
        this.options = options;
    }

    public int getVarbit() {
        return varbit;
    }

    public RSArea getRoom() {
        return room;
    }

    public int getPlaqueID() {
        return plaqueID;
    }

    public List<String> getOptions() {
        return options;
    }

    public static boolean needNextRoom() {
        for (Exhibit e : Exhibit.values()) {
            if (!e.getRoom().contains(Player07.getPosition())) {
                continue;
            }
            if (RSVarBit.get(e.getVarbit()).getValue() != 3) {
                return false;
            }
        }
        return true;
    }

    public static int getNextPlaque() {
        int nextPlaque = 0;
        for (Exhibit e : Exhibit.values()) {
            if (e.getRoom().contains(Player07.getPosition()) && RSVarBit.get(e.getVarbit()).getValue() != 3) {
                nextPlaque = e.plaqueID;
            }
        }
        return nextPlaque;
    }

    public static RSInterface getOption() {
        int decision = Reactions.getDecision(2);
        for (Exhibit e : Exhibit.values()) {
            RSInterface text = Interfaces.get(Constants.QUIZ_MASTER, i -> e.getOptions().contains(i.getText()));
            if (text != null) {
                if (decision < 20) {
                    Logging.debug("Intentionally making an error");
                    if(text.getSibling(1)!=null){
                        return text.getSibling(1);
                    } else if(text.getSibling(-1)!=null){
                        return text.getSibling(-1);
                    }
                } else {
                    return text;
                }
            }
        }
        return null;
    }

    public static RSArea getCurrentRoom(){
        for (Exhibit e : Exhibit.values()) {
            if (e.getRoom().contains(Player07.getPosition())) {
                return e.getRoom();
            }
        } return null;
    }

    public static RSArea getNextRoom() {
        RSArea nextRoom = null;
        int i = 0;
        if (needNextRoom()) {
            while (nextRoom == null && i < Exhibit.values().length - 1) {
                for (Exhibit e : Exhibit.values()) {
                    i++;
                    Exhibit temp = getRandom();
                    if (RSVarBit.get(temp.getVarbit()).getValue() != 3) {
                        Logging.debug("Potential exhibit: " + e.name());
                        nextRoom = temp.getRoom();
                        break;
                    }
                }
            }
        } else {
            for (Exhibit e : Exhibit.values()) {
                if (e.getRoom().contains(Player07.getPosition())) {
                    nextRoom = e.getRoom();
                }
            }
        }
        return nextRoom;
    }

    public static Exhibit getRandom() {
        return values()[General.random(0, values().length - 1)];
    }


}
