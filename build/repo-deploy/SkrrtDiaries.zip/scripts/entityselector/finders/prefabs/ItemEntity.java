package scripts.entityselector.finders.prefabs;

import org.tribot.api.input.Mouse;
import org.tribot.api.types.generic.Filter;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.types.RSItem;

import java.awt.*;
import java.util.Comparator;

/**
 * @author Laniax
 */
public class ItemEntity extends RSItemFinder<ItemEntity> {

    /**
     * {@inheritDoc}
     */
    public RSItem[] getResults() {

        Filter<RSItem> filter = super.buildFilter();

        if (filter != null)
            return Inventory.find(filter); // Remarkably, the Inventory class is the only class without a #getAll(filter) method.

        return Inventory.getAll();
    }

    private static final Comparator<RSItem> closestComparator = getClosestComparator();

    public static Comparator<RSItem> getClosestComparator() {
        Point mousePos = Mouse.getPos();
        return (first, second) -> {
            Rectangle firstArea = first.getArea();
            if (firstArea == null) {
                return 1;
            }
            Rectangle secondArea = second.getArea();
            if (secondArea == null) {
                return -1;
            }
            Point firstPosition = firstArea.getLocation();
            firstPosition.translate(20, 20);
            Point secondPosition = secondArea.getLocation();
            secondPosition.translate(20, 20);
            return Double.compare(firstPosition.distance(mousePos), secondPosition.distance(mousePos));
        };
    }


}
