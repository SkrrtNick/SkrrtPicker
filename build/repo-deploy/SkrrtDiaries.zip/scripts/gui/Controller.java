package scripts.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import org.tribot.api.General;
import org.tribot.util.Util;
import scripts.data.Profile;
import scripts.skrrt_api.util.functions.Logging;
import scripts.utilities.FileUtilities;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static scripts.data.Constants.PROFILE_PATH;
import static scripts.data.Vars.runningPrep;
import static scripts.data.Vars.runtimeSettings;

public class Controller extends AbstractGUIController {
    private String profile = "";
    @FXML
    private ResourceBundle resources;

    @FXML
    private Pane ownerWindow;

    @FXML
    private URL location;

    @FXML
    private CheckBox jumpFence;

    @FXML
    private CheckBox sos;

    @FXML
    private CheckBox giveDogBone;

    @FXML
    private CheckBox buyNewspaper;

    @FXML
    private CheckBox chopTree;

    @FXML
    private CheckBox plank;

    @FXML
    private CheckBox iron;

    @FXML
    private CheckBox runeMysteries;

    @FXML
    private CheckBox thesseliasStore;

    @FXML
    private CheckBox stealTea;

    @FXML
    private CheckBox catchTrout;

    @FXML
    private CheckBox craftEarthRunes;

    @FXML
    private CheckBox haigHalen;

    @FXML
    private CheckBox kudos;

    @FXML
    private CheckBox spinABowl;

    @FXML
    private CheckBox softLevelCaps;

    @FXML
    private CheckBox trainAgility;

    @FXML
    private CheckBox trainCrafting;

    @FXML
    private CheckBox trainRunecrafting;

    @FXML
    private CheckBox trainFishing;

    @FXML
    private CheckBox trainThieving;

    @FXML
    private CheckBox trainMining;

    @FXML
    private MenuItem save;

    @FXML
    private MenuItem load;

    @FXML
    private MenuItem saveAs;

    @FXML
    private MenuItem exit;

    @FXML
    private Button startScriptButton;


    @FXML
    void checkBowl(ActionEvent event) {

    }

    @FXML
    void checkBuyNewspaper(ActionEvent event) {

    }

    @FXML
    void checkCatchTrout(ActionEvent event) {

    }

    @FXML
    void checkChopTree(ActionEvent event) {

    }

    @FXML
    void checkHaigHalen(ActionEvent event) {

    }

    @FXML
    void checkIron(ActionEvent event) {

    }

    @FXML
    void checkJumpFence(ActionEvent event) {

    }

    @FXML
    void checkKudos(ActionEvent event) {

    }

    @FXML
    void checkPlank(ActionEvent event) {

    }

    @FXML
    void checkSos(ActionEvent event) {

    }

    @FXML
    void checkStealTea(ActionEvent event) {

    }

    @FXML
    void checkedRuneMysteries(ActionEvent event) {

    }

    @FXML
    void checkedThesselia(ActionEvent event) {

    }

    @FXML
    void craftEarthRunes(ActionEvent event) {

    }

    @FXML
    void giveDogBone(ActionEvent event) {

    }

    @FXML
    void shouldSoftLevelCaps(ActionEvent event) {

    }


    @FXML
    void shouldTrainAgility(ActionEvent event) {

    }

    @FXML
    void shouldTrainCrafting(ActionEvent event) {

    }
    @FXML
    void shouldTrainRunecrafting(ActionEvent event) {

    }
    @FXML
    void shouldTrainThieving(ActionEvent event){

    }

    @FXML
    void shouldTrainMining(ActionEvent event) {

    }

    @FXML
    void shouldTrainFishing(ActionEvent event){

    }

    @FXML
    void loadClicked(ActionEvent event) {

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Load Profile");
        fileChooser.setInitialDirectory(new File(Util.getWorkingDirectory() + PROFILE_PATH));
        fileChooser.setSelectedExtensionFilter(new FileChooser.ExtensionFilter("JSON files (*.json)", "*.json"));
        File file = fileChooser.showOpenDialog(ownerWindow.getScene().getWindow());
        if (file != null) {
            String fileName = file.getName();
            save.setDisable(false);
            profile = fileName;
            try {
                Profile settings = FileUtilities.gson.fromJson(new String(FileUtilities.loadFile(new File(Util.getWorkingDirectory().getAbsolutePath() + PROFILE_PATH + "/" + fileName))), Profile.class);
                load(settings);
            } catch (IOException e) {
                General.println(e.getMessage());
            }
        } else {
            General.println(file);
        }
    }

    @FXML
    public void saveAsClicked(ActionEvent event) {

        FileChooser fileChooser = new FileChooser();
        Profile settings = new Profile();
        save(settings);
        fileChooser.setTitle("Save Profile");
        fileChooser.setInitialDirectory(new File(Util.getWorkingDirectory() + PROFILE_PATH));
        File file = fileChooser.showSaveDialog(ownerWindow.getScene().getWindow());
        if (file != null) {
            String fileName = file.getName();
            save.setDisable(false);
            if (!fileName.endsWith(".json")) {
                fileName += ".json";
            }
            profile = fileName;
            FileUtilities.createFile(FileUtilities.gson.toJson(settings), PROFILE_PATH + "/" + fileName);
        }
    }


    @FXML
    void exitClicked(ActionEvent event) {
        this.getGUI().close();
        runningPrep = false;
    }

    @FXML
    public void saveClicked(ActionEvent event) {
        Profile settings = new Profile();
        save(settings);
        trainCrafting.setSelected((settings.isShouldTrainCrafting()));
        trainRunecrafting.setSelected((settings.isShouldTrainRunecrafting()));
        trainThieving.setSelected((settings.isShouldTrainThieving()));
        FileUtilities.createFile(FileUtilities.gson.toJson(settings), PROFILE_PATH + "/" + profile);
    }

    @FXML
    public void startScriptPressed() {
        Profile settings = new Profile();
        save(settings);
        FileUtilities.createFile(FileUtilities.gson.toJson(settings), PROFILE_PATH + "/" + "last.json");
        runningPrep = true;
        runtimeSettings = settings;
        this.getGUI().close();
    }

    @Override
    public void initialize() {
        try {
            Profile settings = FileUtilities.gson.fromJson(new String(FileUtilities.loadFile(new File(Util.getWorkingDirectory().getAbsolutePath() + PROFILE_PATH + "/last.json"))), Profile.class);
            load(settings);
        } catch (IOException e) {
            Logging.debug("Wasn't able to load last.json");
        }
    }

    public void load(Profile settings){
        spinABowl.setSelected(settings.isShouldSpinABowl());
        craftEarthRunes.setSelected(settings.isShouldCraftEarthRunes());
        jumpFence.setSelected(settings.isShouldJumpFence());
        sos.setSelected(settings.isShouldSos());
        buyNewspaper.setSelected(settings.isShouldBuyNewspaper());
        chopTree.setSelected(settings.isShouldChopTree());
        plank.setSelected(settings.isShouldPlank());
        iron.setSelected(settings.isShouldIron());
        runeMysteries.setSelected(settings.isShouldRuneMysteries());
        thesseliasStore.setSelected(settings.isShouldThesseliasStore());
        stealTea.setSelected(settings.isShouldStealTea());
        catchTrout.setSelected(settings.isShouldCatchTrout());
        craftEarthRunes.setSelected(settings.isShouldCraftEarthRunes());
        haigHalen.setSelected(settings.isShouldHaigHalen());
        kudos.setSelected(settings.isShouldKudos());
        giveDogBone.setSelected(settings.isShouldGiveDogBone());
        trainAgility.setSelected((settings.isShouldTrainAgility()));
        trainCrafting.setSelected((settings.isShouldTrainCrafting()));
        trainRunecrafting.setSelected((settings.isShouldTrainRunecrafting()));
        trainThieving.setSelected((settings.isShouldTrainThieving()));
        trainFishing.setSelected((settings.isShouldTrainFishing()));
        trainMining.setSelected(settings.isShouldTrainMining());
        softLevelCaps.setSelected(settings.isShouldSoftLevelCaps());
    }
    public void save(Profile settings){
        settings.setShouldSpinABowl(spinABowl.isSelected());
        settings.setShouldCraftEarthRunes(craftEarthRunes.isSelected());
        settings.setShouldJumpFence(jumpFence.isSelected());
        settings.setShouldSos(sos.isSelected());
        settings.setShouldBuyNewspaper(buyNewspaper.isSelected());
        settings.setShouldChopTree(chopTree.isSelected());
        settings.setShouldPlank(plank.isSelected());
        settings.setShouldIron(iron.isSelected());
        settings.setShouldRuneMysteries(runeMysteries.isSelected());
        settings.setShouldThesseliasStore(thesseliasStore.isSelected());
        settings.setShouldStealTea(stealTea.isSelected());
        settings.setShouldCatchTrout(catchTrout.isSelected());
        settings.setShouldCraftEarthRunes(craftEarthRunes.isSelected());
        settings.setShouldHaigHalen(haigHalen.isSelected());
        settings.setShouldKudos(kudos.isSelected());
        settings.setShouldGiveDogBone(giveDogBone.isSelected());
        settings.setShouldSoftLevelCaps(softLevelCaps.isSelected());
        settings.setShouldTrainAgility(trainAgility.isSelected());
        settings.setShouldTrainCrafting(trainCrafting.isSelected());
        settings.setShouldTrainRunecrafting((trainRunecrafting.isSelected()));
        settings.setShouldTrainThieving((trainThieving.isSelected()));
        settings.setShouldTrainFishing((trainFishing.isSelected()));
        settings.setShouldTrainMining((trainMining.isSelected()));
    }

}
