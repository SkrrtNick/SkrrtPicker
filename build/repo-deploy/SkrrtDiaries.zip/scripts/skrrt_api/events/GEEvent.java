package scripts.skrrt_api.events;

import obf.E;
import org.tribot.api.DynamicClicking;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api2007.*;
import org.tribot.api2007.types.*;
import org.tribot.script.Script;
import scripts.skrrt_api.events.BankEventV2;
import scripts.skrrt_api.events.InventoryEvent;
import scripts.skrrt_api.util.functions.*;
import scripts.skrrt_api.util.items.ExchangeBoxes;
import scripts.skrrt_api.util.items.GrandExchangeItem;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class GEEvent extends BotEvent {

    public HashMap<String, GrandExchangeItem> grandExchangeItemHashMap = new HashMap<String, GrandExchangeItem>();
    ExchangeBoxes exchangeBoxes = new ExchangeBoxes();
    BankEventV2 bankEvent;

    RSArea grandExchangeArea = new RSArea(
            new RSTile[]{
                    new RSTile(3157, 3494, 0),
                    new RSTile(3157, 3487, 0),
                    new RSTile(3162, 3483, 0),
                    new RSTile(3169, 3483, 0),
                    new RSTile(3173, 3487, 0),
                    new RSTile(3173, 3494, 0),
                    new RSTile(3168, 3498, 0),
                    new RSTile(3161, 3498, 0)
            }
    );

    public GEEvent(Script script, BankEventV2 bankEvent) {
        super(script);
        this.bankEvent = bankEvent;

    }

    public GEEvent addReq(String itemName, int id, int qty, int price) {
        setGrandExchangeItemIDList(itemName, id, qty, price);
        return this;
    }


    public boolean isPendingOperation() {
        for (Map.Entry<String, GrandExchangeItem> grandExchangeList : grandExchangeItemHashMap.entrySet()) {
            String itemName = grandExchangeList.getKey();
            int itemID = grandExchangeList.getValue().getId();
            int itemAmount = grandExchangeList.getValue().getQty();
            int itemPrice = grandExchangeList.getValue().getPrice();
            if (bankEvent.bankCacheHashMap.isEmpty()) {
                Logging.message("We need to have a cache first");
                if(Banking07.openBank()){
                    Sleep.until(Banking07::isBankLoaded);
                    Logging.message("Trying to update cache");
                    bankEvent.updateCache();
                }
            } else {
                if (!bankEvent.bankCacheHashMap.containsKey(itemName) || (bankEvent.bankCacheHashMap.containsKey(itemName) && bankEvent.bankCacheHashMap.get(itemName).getQty() == 0)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void setGrandExchangeItemIDList(String itemName, int id, int qty, int price) {
        grandExchangeItemHashMap.put(itemName, new GrandExchangeItem(itemName, id, qty, price));
    }

    public void setGrandExchangeItemList(String itemName, int qty, int price) {
        grandExchangeItemHashMap.put(itemName, new GrandExchangeItem(itemName, qty, price));
    }


    @Override
    public void step() throws InterruptedException, IOException {
        if (!grandExchangeArea.contains(me())) {
            Traversing.walkTo(grandExchangeArea);
        } else {
            if (needCoins()) {
                getCoins();
            } else if (Banking.isBankScreenOpen()) {
                Banking.close();
                Timing.waitCondition(() -> !Banking.isBankScreenOpen(), 4000);
            } else if (canOpenExchange()) {
                openGrandExchange();
            } else {
                for (Map.Entry<String, GrandExchangeItem> grandExchangeItems : grandExchangeItemHashMap.entrySet()) {
                    String itemName = grandExchangeItems.getKey();
                    int qty;
                    if (bankEvent.bankCacheHashMap.get(itemName) != null) {
                        qty = grandExchangeItems.getValue().getQty() - bankEvent.bankCacheHashMap.get(itemName).getQty();
                    } else {
                        qty = grandExchangeItems.getValue().getQty();
                    }
                    int price = grandExchangeItems.getValue().getPrice();
                    RSGEOffer nextOffer = exchangeBoxes.getRandomEmptyBox();
                    if(nextOffer != null && nextOffer.click()){
                        if(GrandExchange.offer(itemName,price,qty,false)){
                            Sleep.until(()->GrandExchange07.getWindowState().equals(GrandExchange07.WINDOW_STATE.SELECTION_WINDOW));
                        }
                    }
                }
            }
        }
    }

    public boolean needCoins() {
        return !InventoryEvent.contains("Coins");
    }

    public void getCoins() throws IOException, InterruptedException {
        new BankEventV2(script).addReq("Coins", Integer.MAX_VALUE).execute();
    }

    public boolean canOpenExchange() {
        return GrandExchange.getWindowState() == null;
    }

    public void openGrandExchange() {
        RSNPC[] clerk = NPCs.find(Constants.IDs.NPCs.ge_clerk);
        RSObject booth = Interaction.getObject("Grand Exchange Booth","Exchange");
        if (booth != null) {
            if (DynamicClicking.clickRSObject(booth, "Exchange")) {
                Timing.waitCondition(() -> GrandExchange.getWindowState() != null, 5000);
            }
        }
    }

    public RSPlayer me() {
        return Player.getRSPlayer();
    }

    public GEEvent addReq(String itemName, int qty, int price) {
        grandExchangeItemHashMap.put(itemName, new GrandExchangeItem(itemName, qty, price));
        return this;
    }
    public GEEvent addReq(int id, int qty, int price) {
        String itemName = RSItemDefinition.get(id).getName();
        if(itemName!=null){
            grandExchangeItemHashMap.put(itemName, new GrandExchangeItem(id, qty, price));
        }
        return this;
    }
}