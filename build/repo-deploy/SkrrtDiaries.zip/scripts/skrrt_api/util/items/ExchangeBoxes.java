package scripts.skrrt_api.util.items;

import org.tribot.api.input.Mouse;
import org.tribot.api2007.Interfaces;
import org.tribot.api2007.types.RSGEOffer;
import org.tribot.api2007.types.RSInterface;
import org.tribot.api2007.types.RSItem;
import scripts.skrrt_api.util.functions.GrandExchange07;
import scripts.skrrt_api.util.numbers.Reactions;

import java.awt.*;
import java.util.Arrays;
import java.util.Comparator;

public class ExchangeBoxes {
    public RSInterface Box1 = Interfaces.get(465, 7);
    public RSInterface Box2 = Interfaces.get(465, 8);
    public RSInterface Box3 = Interfaces.get(465, 9);
    public RSInterface Box4 = Interfaces.get(465, 10);
    public RSInterface Box5 = Interfaces.get(465, 11);
    public RSInterface Box6 = Interfaces.get(465, 12);
    public RSInterface Box7 = Interfaces.get(465, 13);
    public RSInterface Box8 = Interfaces.get(465, 14);

    public int buyChild = 3;
    public int sellChild = 4;

    //Actions Sell: Create <col=ff9040>Sell</col> offer
    //Actions Buy: Create <col=ff9040>Buy</col> offer

    public int itemTextChild = 19;

    public int offerTypeChild = 16;

    public boolean isBoxEmpty(RSInterface box) {
        return Interfaces.isInterfaceSubstantiated(box.getChild(buyChild));
    }

    public RSInterface getFirstEmptyBox() {
        if (Interfaces.isInterfaceSubstantiated(Box1.getChild(buyChild))) {
            return Box1;
        } else if (Interfaces.isInterfaceSubstantiated(Box2.getChild(buyChild))) {
            return Box2;
        } else if (Interfaces.isInterfaceSubstantiated(Box3.getChild(buyChild))) {
            return Box3;
        } else if (Interfaces.isInterfaceSubstantiated(Box4.getChild(buyChild))) {
            return Box4;
        } else if (Interfaces.isInterfaceSubstantiated(Box5.getChild(buyChild))) {
            return Box5;
        } else if (Interfaces.isInterfaceSubstantiated(Box6.getChild(buyChild))) {
            return Box6;
        } else if (Interfaces.isInterfaceSubstantiated(Box7.getChild(buyChild))) {
            return Box7;
        } else if (Interfaces.isInterfaceSubstantiated(Box8.getChild(buyChild))) {
            return Box8;
        }
        return null;
    }

    public RSGEOffer getRandomEmptyBox() {
        RSGEOffer[] currentOffers = GrandExchange07.getOffers();
        RSGEOffer nextOffer = null;
        int decision = Reactions.getDecision(1);
        for (RSGEOffer currentOffer : currentOffers) {
            if (currentOffer.getStatus().equals(RSGEOffer.STATUS.EMPTY)) {
                if (nextOffer == null) {
                    nextOffer = currentOffer;
                }
                if (decision > 50) {
                    break;
                } else {
                    nextOffer = currentOffer;
                }
            }
        } return nextOffer;
    }

}
