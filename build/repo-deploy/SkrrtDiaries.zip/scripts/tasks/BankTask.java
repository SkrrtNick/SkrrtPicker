package scripts.tasks;

import scripts.data.Constants;
import scripts.data.Diaries;
import scripts.data.Vars;

import scripts.skrrt_api.task.Priority;
import scripts.skrrt_api.task.Task;
import scripts.skrrt_api.util.functions.Banking07;
import scripts.skrrt_api.util.functions.Logging;
import scripts.skrrt_api.util.items.BankItem;
import scripts.skrrt_api.util.items.ItemCollections;
import scripts.skrrt_api.util.items.ItemID;
import scripts.skrrt_api.util.items.NewBankItem;

import java.util.ArrayList;

import static scripts.data.Vars.*;

public class BankTask implements Task {

    @Override
    public Priority priority() {
        return Priority.HIGH;
    }

    @Override
    public boolean validate() {
        return Vars.initialCheck && Vars.shouldWithdrawItems;
    }

    @Override
    public void execute() {}}

//        BankEvent event = BankEvent.builder()
//                .bankItem(new NewBankItem(ItemID.VARROCK_TELEPORT, 0))
//                .bankItem(new NewBankItem(ItemCollections.getRingsOfWealth(), 0))
//                .bankItem(new NewBankItem(ItemCollections.getAmuletsOfGlories(), 0))
//                .bankItem(new NewBankItem(ItemID.VARROCK_TELEPORT, 0))
//                .bankItem(new NewBankItem(ItemID.SOFT_CLAY, 1, ()->!Diaries.FIRE_A_BOWL.isCompleted() && runtimeSettings.isShouldSpinABowl()))
//                .bankItem(new NewBankItem(ItemID.PURE_ESSENCE, 1, ()->!Diaries.RUNECRAFT_EARTH_RUNE.isCompleted() && runtimeSettings.isShouldRuneMysteries()))
//                .bankItem(new NewBankItem(ItemID.EARTH_TIARA, 1, ()->!Diaries.RUNECRAFT_EARTH_RUNE.isCompleted() && runtimeSettings.isShouldRuneMysteries()))
//                .bankItem(new NewBankItem(ItemID.FLY_FISHING_ROD, 1, ()->!Diaries.TROUT.isCompleted() && runtimeSettings.isShouldCatchTrout()))
//                .bankItem(new NewBankItem(ItemID.FEATHER, 0, ()->!Diaries.TROUT.isCompleted() && runtimeSettings.isShouldCatchTrout()))
//                .bankItem(new NewBankItem(ItemID.COINS, 0, ()->!Diaries.BUYNEWSPAPER.isCompleted() && runtimeSettings.isShouldBuyNewspaper()))
//                .bankItem(new NewBankItem(ItemID.COINS, 0, ()->!Diaries.PLANK.isCompleted() && runtimeSettings.isShouldPlank()))
//                .bankItem(new NewBankItem(ItemID.LOGS, 1, ()->!Diaries.PLANK.isCompleted() && runtimeSettings.isShouldPlank()))
//                .bankItem(new NewBankItem(ItemID.BRONZE_AXE, 1, ()->!Diaries.DYING_TREE.isCompleted() && runtimeSettings.isShouldChopTree()))
//                .bankItem(new NewBankItem(ItemID.BRONZE_PICKAXE, 1, ()->!Diaries.IRON.isCompleted() && runtimeSettings.isShouldIron()))
//                .bankItem(new NewBankItem(ItemID.BONES, 1, ()->!Diaries.GIVE_DOG_BONE.isCompleted() && runtimeSettings.isShouldGiveDogBone()))
//                .build();

////        if (event.execute()) {
//            Logging.debug("Successfully completed bank task");
//            runningList = true;
//            runningPrep = false;
//            shouldWithdrawItems = false;
//        } else {
//            Logging.debug("Failed to complete bank task");
//            shouldBuyItems = true;
//            runningPrep = true;
//            runningList = false;
//        }
//    }
