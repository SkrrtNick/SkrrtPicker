package scripts.tasks;

import org.tribot.api.General;
import org.tribot.api2007.Game;
import scripts.data.Constants;
import scripts.data.Diaries;
import scripts.skrrt_api.task.Priority;
import scripts.skrrt_api.task.Task;
import scripts.skrrt_api.util.functions.Logging;
import scripts.skrrt_api.util.items.ExchangeItem;
import scripts.skrrt_api.util.items.ItemCollections;
import scripts.skrrt_api.util.items.ItemID;

import static scripts.data.Vars.*;

public class BuyItems implements Task {
    private boolean start;

    @Override
    public Priority priority() {
        return Priority.MEDIUM;
    }

    @Override
    public boolean validate() {
        return shouldBuyItems && initialCheck;
    }

    @Override
    public void execute() {
//
//        GEEvent exchangeEvent = GEEvent.builder()
//                .exchangeItem(new ExchangeItem(ItemID.LEATHER, requiredLeather, () -> runtimeSettings.isShouldTrainCrafting() && actualCrafting < goalCrafting))
//                .exchangeItem(new ExchangeItem(ItemID.THREAD, requiredLeather / 5, () -> runtimeSettings.isShouldTrainCrafting() && actualCrafting < goalCrafting))
//                .exchangeItem(new ExchangeItem(ItemID.NEEDLE, General.random(1, 3), () -> runtimeSettings.isShouldTrainCrafting() && actualCrafting < goalCrafting))
//                .exchangeItem(new ExchangeItem(ItemID.CAMELOT_TELEPORT, General.random(1, 3), () -> runtimeSettings.isShouldTrainFishing() && actualFishing < goalFishing))
//                .exchangeItem(new ExchangeItem(ItemID.SMALL_FISHING_NET, 1, () -> runtimeSettings.isShouldTrainFishing() && actualFishing < goalFishing))
//                .exchangeItem(new ExchangeItem(ItemID.FALADOR_TELEPORT, General.random(1, 2), () -> runtimeSettings.isShouldTrainMining() && Game.getSetting(Constants.DORICS_QUEST) < 99))
//                .exchangeItem(new ExchangeItem(ItemID.COPPER_ORE, 4, () -> runtimeSettings.isShouldTrainMining() && Game.getSetting(Constants.DORICS_QUEST) < 99))
//                .exchangeItem(new ExchangeItem(ItemID.CLAY, 6, () -> runtimeSettings.isShouldTrainMining() && Game.getSetting(Constants.DORICS_QUEST) < 99))
//                .exchangeItem(new ExchangeItem(ItemID.IRON_ORE, 2, () -> runtimeSettings.isShouldTrainMining() && Game.getSetting(Constants.DORICS_QUEST) < 99))
//                .exchangeItem(new ExchangeItem(ItemID.DWELLBERRIES, 1, () -> runtimeSettings.isShouldTrainMining() && Game.getSetting(Constants.PLAGUE_CITY) <= 1))
//                .exchangeItem(new ExchangeItem(ItemID.ROPE, 1, () -> runtimeSettings.isShouldTrainMining() && Game.getSetting(Constants.PLAGUE_CITY) <= 8))
//                .exchangeItem(new ExchangeItem(ItemID.SPADE, 1, () -> runtimeSettings.isShouldTrainMining() && Game.getSetting(Constants.PLAGUE_CITY) <= 7))
//                .exchangeItem(new ExchangeItem(ItemID.BUCKET_OF_WATER, 4, () -> runtimeSettings.isShouldTrainMining() && Game.getSetting(Constants.PLAGUE_CITY) <= 6))
//                .exchangeItem(new ExchangeItem(ItemID.BUCKET_OF_MILK, 1, () -> runtimeSettings.isShouldTrainMining() && Game.getSetting(Constants.PLAGUE_CITY) <= 26))
//                .exchangeItem(new ExchangeItem(ItemID.CHOCOLATE_DUST, 1, () -> runtimeSettings.isShouldTrainMining() && Game.getSetting(Constants.PLAGUE_CITY) <= 26))
//                .exchangeItem(new ExchangeItem(ItemID.SNAPE_GRASS, 1, () -> runtimeSettings.isShouldTrainMining() && Game.getSetting(Constants.PLAGUE_CITY) <= 26))
//                .exchangeItem(new ExchangeItem(ItemCollections.getSkillNecklaces(), 1, () -> runtimeSettings.isShouldTrainMining() && Game.getSetting(Constants.PLAGUE_CITY) <= 28))
//                .exchangeItem(new ExchangeItem(ItemID.BRONZE_PICKAXE, 1, () -> !Diaries.IRON.isCompleted() && runtimeSettings.isShouldIron()))
//                .exchangeItem(new ExchangeItem(ItemID.BRONZE_AXE, 1, () -> !Diaries.DYING_TREE.isCompleted() && runtimeSettings.isShouldChopTree()))
//                .exchangeItem(new ExchangeItem(ItemID.FLY_FISHING_ROD, 1, () -> !Diaries.TROUT.isCompleted() && runtimeSettings.isShouldCatchTrout()))
//                .exchangeItem(new ExchangeItem(ItemID.FEATHER, General.random(1, 50), () -> !Diaries.TROUT.isCompleted() && runtimeSettings.isShouldCatchTrout()))
//                .exchangeItem(new ExchangeItem(ItemID.EARTH_TIARA, 1, () -> !Diaries.RUNECRAFT_EARTH_RUNE.isCompleted() && runtimeSettings.isShouldCraftEarthRunes()))
//                .exchangeItem(new ExchangeItem(ItemID.PURE_ESSENCE, 1, () -> !Diaries.RUNECRAFT_EARTH_RUNE.isCompleted() && runtimeSettings.isShouldCraftEarthRunes()))
//                .exchangeItem(new ExchangeItem(ItemID.SOFT_CLAY, 1, () -> !Diaries.FIRE_A_BOWL.isCompleted() && runtimeSettings.isShouldSpinABowl()))
//                .exchangeItem(new ExchangeItem(ItemID.BONES, 1, () -> !Diaries.GIVE_DOG_BONE.isCompleted() && runtimeSettings.isShouldGiveDogBone()))
//                .exchangeItem(new ExchangeItem(ItemID.VARROCK_TELEPORT, General.random(8, 14), () -> true))
//                .exchangeItem(new ExchangeItem(ItemID.LUMBRIDGE_TELEPORT, General.random(2, 4),() -> runtimeSettings.isShouldRuneMysteries() && Game.getSetting(Constants.RUNE_MYSTERIES) < 6))
//                .exchangeItem(new ExchangeItem(ItemCollections.getRingsOfWealth(), 1, () -> true))
//                .exchangeItem(new ExchangeItem(ItemCollections.getAmuletsOfGlories(), General.random(1, 2), () -> ((runtimeSettings.isShouldTrainAgility() && actualAgility < 20) || runtimeSettings.isShouldTrainRunecrafting() && actualRunecrafting < 9) || (runtimeSettings.isShouldCatchTrout() && !Diaries.TROUT.isCompleted())))
//                .exchangeItem(new ExchangeItem(ItemCollections.getNecklacesOfPassage(), General.random(1, 2), () -> ((runtimeSettings.isShouldTrainAgility() && actualAgility < 10) || (runtimeSettings.isShouldTrainRunecrafting() && actualRunecrafting < 9) || (runtimeSettings.isShouldRuneMysteries() && Game.getSetting(Constants.RUNE_MYSTERIES) < 6))))
//                .build();
//        GrandExchangeEvent grandExchangeEvent;
//
//        if (exchangeEvent.execute()) {
//            Logging.debug("Successfully performed GE Event");
//            shouldBuyItems = false;
//        } else {
//            Logging.debug("Failed to complete GE Event");
//        }
    }


    @Override
    public String toString() {
        return "Performing GE Event";
    }

}
