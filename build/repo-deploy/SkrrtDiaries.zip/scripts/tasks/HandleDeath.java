package scripts.tasks;

import scripts.dax_api.walker_engine.interaction_handling.NPCInteraction;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.input.Keyboard;
import org.tribot.api2007.Interfaces;
import org.tribot.api2007.NPCChat;

import scripts.entityselector.Entities;
import scripts.entityselector.finders.prefabs.InterfaceEntity;
import scripts.skrrt_api.task.Priority;
import scripts.skrrt_api.task.Task;
import scripts.skrrt_api.util.functions.Interaction;
import scripts.skrrt_api.util.numbers.Reactions;

public class HandleDeath implements Task {
    boolean hasInteracted = false;

    @Override
    public Priority priority() {
        return Priority.HIGH;
    }

    @Override
    public boolean validate() {
        return Interaction.npcExists("Death");
    }

    @Override
    public String toString() {
        return "Handling Death";
    }

    @Override
    public void execute() {
        if(!hasInteracted && Interaction.clickNPC("Death")){
            Timing.waitCondition(NPCInteraction::isConversationWindowUp, Reactions.getAFK());
            while(NPCInteraction.isConversationWindowUp()){
                General.sleep(Reactions.getNormal());
                NPCInteraction.handleConversation("How does that work?","What is this place?","Yes, have you got anything for me?","Can I choose a different-looking gravestone?","How do I pay a gravestone fee?","How long do I have to return to my gravestone?","How do I know what will happen to my items when I die?","I think I'm done here.");
            }while(Interfaces.isInterfaceSubstantiated(NPCChat.getClickContinueInterface())){
                General.sleep(Reactions.getPredictable());
                NPCChat.clickContinue(true);
            }
            while(Interfaces.findWhereAction("Continue") != null || Entities.find(InterfaceEntity::new).textContains("continue").getFirstResult() != null){
                int decision = Reactions.getDecision(2);
                if(decision<50){
                    Interfaces.findWhereAction("Continue").click();
                    Entities.find(InterfaceEntity::new).textContains("continue").getFirstResult().click();
                    General.sleep(Reactions.getNormal());
                } else {
                    Keyboard.typeString(" ");
                    General.sleep(Reactions.getNormal());
                } General.sleep(Reactions.getNormal());
            }
            if(!NPCInteraction.isConversationWindowUp()){
                hasInteracted = true;
            }
        }
        if((!NPCInteraction.isConversationWindowUp() || !Interfaces.isInterfaceSubstantiated(633)|| !Interfaces.isInterfaceSubstantiated(11)) && hasInteracted){
            //TO DO COLLECT ITEMS

            Interaction.clickObject("Portal");
        }
    }
}
