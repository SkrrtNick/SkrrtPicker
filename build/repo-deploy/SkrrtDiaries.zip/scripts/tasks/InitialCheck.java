package scripts.tasks;

import org.tribot.api.General;
import org.tribot.api2007.Game;
import org.tribot.api2007.Skills;
import org.tribot.api2007.types.RSVarBit;
import scripts.data.Constants;
import scripts.data.crafting.CraftableItems;
import scripts.skrrt_api.task.Priority;
import scripts.skrrt_api.task.Task;
import scripts.skrrt_api.util.functions.*;
import scripts.skrrt_api.util.numbers.Reactions;

import static scripts.data.Vars.*;

public class InitialCheck implements Task {

    @Override
    public String toString() {
        return "Performing Initial Check";
    }

    @Override
    public Priority priority() {
        return Priority.HIGH;
    }

    @Override
    public boolean validate() {
        return Game.getGameState() == 30 && runtimeSettings != null && !initialCheck;
    }

    @Override
    public void execute() {
        currentTask = "Initialising";

        //Agility
        actualAgility = Skills.SKILLS.AGILITY.getActualLevel();
        if (actualAgility >= 13) {
            runtimeSettings.shouldTrainAgility = false;
        } else if (runtimeSettings.shouldSoftLevelCaps) {
            goalAgility = General.random(0, 7) + 13;
        } else {
            goalAgility = 13;
        }
        //Crafting
        actualCrafting = Skills.SKILLS.CRAFTING.getActualLevel();
        if (actualCrafting >= 8) {
            runtimeSettings.shouldTrainCrafting = false;
        } else if (runtimeSettings.shouldSoftLevelCaps) {
            goalCrafting = General.random(0, 6) + 9;
        } else {
            goalCrafting = 8;
        }
        requiredLeather = CraftableItems.getRequiredLeather(goalCrafting) + General.random(1, 20);

        //Runecrafting
        actualRunecrafting = Skills.SKILLS.RUNECRAFTING.getActualLevel();
        goalRunecrafting = 9;

        //Thieving
        actualThieving = Skills.SKILLS.THIEVING.getActualLevel();
        if (actualThieving >= 5) {
            runtimeSettings.shouldTrainThieving = false;
        } else if (runtimeSettings.shouldSoftLevelCaps) {
            goalThieving = General.random(0, 5) + 5;
        } else {
            goalThieving = 5;
        }
        //FISHING
        actualFishing = Skills.SKILLS.FISHING.getActualLevel();
        if (actualFishing >= 20) {
            runtimeSettings.shouldTrainFishing = false;
        } else if (runtimeSettings.shouldSoftLevelCaps) {
            goalFishing = General.random(0, 5) + 20;
        } else {
            goalFishing = 20;
        }

        //MINING
        actualMining = Skills.SKILLS.FISHING.getActualLevel();
        if (actualMining >= 15) {
            runtimeSettings.shouldTrainMining = false;

//        } else if (runtimeSettings.shouldSoftLevelCaps) {
//            goalMining = General.random(0, 5) + 15;
        } else {
            goalMining = 15;
        }

        //KUDOS
        kudos = RSVarBit.get(Constants.KUDOS_VARBIT).getValue();
        GrandExchange07.close();
        if (Banking07.isInBank()) {
            if (Banking07.openBank()) {
                Sleep.until(Banking07::isBankLoaded);
                Banking07.closeBankTutorial();
                if (!Inventory07.isEmpty()) {
                    Banking07.depositAll();
                    Sleep.until(Inventory07::isEmpty);
                }
                General.sleep(Reactions.getNormal());
                initialCheck = true;
            }
        } else {
            Traversing.walkToBank();
        }
    }
}

