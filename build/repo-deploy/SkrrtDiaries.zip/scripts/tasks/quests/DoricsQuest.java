//package scripts.tasks.quests;
//
//import org.tribot.api2007.Banking;
//import org.tribot.api2007.Game;
//import scripts.SkrrtDiaries;
//import scripts.data.Constants;
//import scripts.data.Vars;
//import scripts.skrrt_api.task.Priority;
//import scripts.skrrt_api.task.Task;
//import scripts.skrrt_api.util.functions.*;
//import scripts.skrrt_api.util.items.BankItem;
//
//import java.util.ArrayList;
//
//import static scripts.data.Vars.*;
//
//public class DoricsQuest implements Task {
//    private boolean start = false;
//    ArrayList<BankItem> bankItems = new ArrayList<>() {{
//        add(new BankItem(Constants.CLAY, 6, true, Constants.DORICS_QUEST, 99));
//        add(new BankItem(Constants.COPPER_ORE, 4, true, Constants.DORICS_QUEST, 99));
//        add(new BankItem(Constants.IRON_ORE, 2, true, Constants.DORICS_QUEST, 99));
//        add(new BankItem(Constants.FALADOR_TELEPORT, 0, true, Constants.DORICS_QUEST, 99));
//        add(new BankItem(0, true, Constants.AMULET_OF_GLORY));
//        add(new BankItem(0, true, Constants.VARROCK_TELEPORT));
//    }};
//
//
//    @Override
//    public Priority priority() {
//        return Priority.HIGH;
//    }
//
//    @Override
//    public boolean validate() {
//        return initialCheck && Vars.runtimeSettings.shouldTrainMining && Game.getSetting(Constants.DORICS_QUEST) < 10 && actualMining < goalMining;
//    }
//
//    @Override
//    public String toString() {
//        return "Doing Doric's";
//    }
//
//    @Override
//    public void execute() {
//        while (!start) {
////            if (!Banking07.withdrawEvent(bankItems,true)) {
////                Logging.debug("Doesn't have the required items in the inventory, will check bank");
////                shouldWithdrawItems = true;
////                runningPrep = true;
////                runningList = false;
////                break;
////            } else {
////                start = true;
////            }
////            Sleep.until(Inventory07.hasRequired(bankItems));
////        }
////        if (start) {
////            if (Game.getSetting(Constants.DORICS_QUEST) == 0) {
////                currentTask = "Walking to Doric";
////                Interaction.handleQuestNPC("Doric", Constants.DORIC_AREA, "I wanted to use your anvils.", "Yes, I will get you the materials.");
////            }
////        }
//        }
//    }
//}