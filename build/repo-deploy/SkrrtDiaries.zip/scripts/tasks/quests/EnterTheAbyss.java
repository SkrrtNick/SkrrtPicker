//package scripts.tasks.quests;
//
//import org.tribot.api.General;
//import org.tribot.api.Timing;
//import org.tribot.api2007.Game;
//import org.tribot.api2007.types.RSVarBit;
//import scripts.data.Constants;
//import scripts.data.Vars;
//import scripts.dax_api.api_lib.DaxWalker;
//import scripts.dax_api.api_lib.models.RunescapeBank;
//import scripts.skrrt_api.task.Priority;
//import scripts.skrrt_api.task.Task;
//import scripts.skrrt_api.util.functions.*;
//import scripts.skrrt_api.util.items.ItemCollections;
//import scripts.skrrt_api.util.items.ItemID;
//import scripts.skrrt_api.util.items.NewBankItem;
//import scripts.skrrt_api.util.npc.NpcID;
//import scripts.skrrt_api.util.numbers.Reactions;
//
//import java.util.ArrayList;
//
//import static scripts.data.Vars.*;
//
//public class EnterTheAbyss implements Task {
////    ArrayList<Integer> SCRYING_ORB = new ArrayList<>() {
////        {
////            add(ItemID.SCRYING_ORB_5519);
////            add(ItemID.SCRYING_ORB);
////        }
////    };
////
////    BankEvent enterTheAbyss = BankEvent.builder()
////            .bankItem(new NewBankItem(ItemID.VARROCK_TELEPORT, 0))
////            .bankItem(new NewBankItem(ItemCollections.getAmuletsOfGlories(), 1))
////            .bankItem(new NewBankItem(ItemCollections.getNecklacesOfPassage(), 1))
////            .bankItem(new NewBankItem(SCRYING_ORB, 1, () -> Game.getSetting(Constants.ENTER_THE_ABYSS) >= 2))
////            .build();
//
//    @Override
//    public Priority priority() {
//        return Priority.HIGH;
//    }
//
//    @Override
//    public boolean validate() {
//        return Vars.runtimeSettings.shouldTrainRunecrafting && Game.getSetting(Constants.ENTER_THE_ABYSS) < 4 && Game.getSetting(Constants.RUNE_MYSTERIES) >= 6 && actualRunecrafting < goalRunecrafting;
//    }
//
//    @Override
//    public String toString() {
//        return "Doing Enter The Abyss";
//    }
//
//    @Override
//    public void execute() {
//        switch (Game.getSetting(Constants.ENTER_THE_ABYSS)) {
//            case 0 -> {
//                if (!Inventory07.isEmpty() || !Player07.isNaked()) {
//                    currentTask = "Banking";
//                    DaxWalker.walkToBank(RunescapeBank.EDGEVILLE);
//                    Timing.waitCondition(Banking07::isInBank, Reactions.getAFK());
//                    if (Banking07.isInBank()) {
//                        if (Banking07.openBank()) {
//                            Banking07.depositAll();
//                            General.sleep(Reactions.getNormal());
//                            Banking07.depositEquipment();
//                        }
//                    }
//                } else {
//                    Interaction.handleQuestNPC(3228, Constants.MAGE_OF_ZAMORAK_AREA);
//                }
//            }
//            case 1 -> {
//                if (enterTheAbyss.hasRequiredItems()) {
//                    currentTask = "Starting Enter the Abyss";
//                    Interaction.handleQuestNPC(NpcID.MAGE_OF_ZAMORAK_2582, Constants.MAGE_OF_ZAMORAK_AREA2, "Where do you get your runes from?", "Yes");
//                } else {
//                    if (!enterTheAbyss.execute()) {
//                        Logging.debug("Banking Event Failed (a)");
//                        runningPrep = true;
//                        runningList = false;
//                        shouldBuyItems = true;
//                    }
//                }
//            }
//            case 2 -> {
//                if (!enterTheAbyss.hasRequiredItems()) {
//                    if (enterTheAbyss.execute()) {
//                        currentTask = "Withdrawing Required Items";
//                    } else {
//                        Logging.debug("Failed banking event (b)");
//                        runningPrep = true;
//                        runningList = false;
//                        shouldBuyItems = true;
//                    }
//                }
//                if (RSVarBit.get(Constants.TELEPORT_FROM_AUBURY).getValue() == 0) {
//                    currentTask = "Walking to Aubury";
//                    if (Interaction.handleQuestNPC(NpcID.AUBURY, "Teleport", Constants.AUBURY_AREA)) {
//                        Sleep.until(()->!Constants.AUBURY_AREA.contains(Player07.getPosition()));
//                    }
//                }
//                if (RSVarBit.get(Constants.TELEPORT_FROM_WIZARD_CROMPERTY).getValue() == 0) {
//                    currentTask = "Walking to Wizard Cromperty";
//                    if (Interaction.handleQuestNPC(NpcID.WIZARD_CROMPERTY, "Teleport", Constants.WIZARD_CROMPERTY_AREA)) {
//                        Sleep.until(()->!Constants.WIZARD_CROMPERTY_AREA.contains(Player07.getPosition()));
//                    }
//                }
//                if (RSVarBit.get(Constants.TELEPORT_FROM_SEDRIDOR).getValue() == 0) {
//                    currentTask = "Walking to Sedridor";
//                    if (Interaction.handleQuestNPC(NpcID.SEDRIDOR, "Teleport", Constants.SEDRIDOR_AREA)) {
//                        Sleep.until(()->!Constants.SEDRIDOR_AREA.contains(Player07.getPosition()));
//                    }
//                }
//
//                if (RSVarBit.get(Constants.TELEPORT_FROM_AUBURY).getValue() > 0 && RSVarBit.get(Constants.TELEPORT_FROM_SEDRIDOR).getValue() > 0 && RSVarBit.get(Constants.TELEPORT_FROM_WIZARD_CROMPERTY).getValue() > 0) {
//                    currentTask = "Turning in Quest";
//                    Interaction.handleQuestNPC(NpcID.MAGE_OF_ZAMORAK_2582, Constants.MAGE_OF_ZAMORAK_AREA2, "Where do you get your runes from?", "Yes");
//                }
//
//            }
//        }
//    }
//}
