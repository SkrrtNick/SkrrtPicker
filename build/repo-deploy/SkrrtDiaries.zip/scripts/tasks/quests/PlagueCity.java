//package scripts.tasks.quests;
//
//import scripts.dax_api.walker_engine.interaction_handling.NPCInteraction;
//import org.tribot.api.General;
//import org.tribot.api2007.Equipment;
//import org.tribot.api2007.Game;
//import org.tribot.api2007.types.RSVarBit;
//import scripts.data.Constants;
//import scripts.data.Vars;
//import scripts.skrrt_api.events.BankEvent;
//import scripts.skrrt_api.task.Priority;
//import scripts.skrrt_api.task.Task;
//import scripts.skrrt_api.util.functions.*;
//import scripts.skrrt_api.util.items.BankItem;
//import scripts.skrrt_api.util.items.ItemCollections;
//import scripts.skrrt_api.util.items.ItemID;
//import scripts.skrrt_api.util.items.NewBankItem;
//
//import java.util.ArrayList;
//
//import static scripts.data.Vars.*;
//
//public class PlagueCity implements Task {
//    boolean start = false;
//
//    BankEvent plagueItems = BankEvent.builder()
//            .bankItem(new NewBankItem( ItemID.DWELLBERRIES,1,()->Game.getSetting(Constants.PLAGUE_CITY) <= 1))
//            .bankItem(new NewBankItem( ItemID.ROPE,1,()->Game.getSetting(Constants.PLAGUE_CITY) <= 8))
//            .bankItem(new NewBankItem( ItemID.SPADE,1,()->Game.getSetting(Constants.PLAGUE_CITY) <= 7))
//            .bankItem(new NewBankItem( ItemID.BUCKET_OF_WATER,4,()->Game.getSetting(Constants.PLAGUE_CITY) <= 6))
//            .bankItem(new NewBankItem( ItemID.BUCKET_OF_MILK,1,()->Game.getSetting(Constants.PLAGUE_CITY) <= 26))
//            .bankItem(new NewBankItem( ItemID.CHOCOLATE_DUST,1,()->Game.getSetting(Constants.PLAGUE_CITY) <= 26))
//            .bankItem(new NewBankItem( ItemID.SNAPE_GRASS,1,()->Game.getSetting(Constants.PLAGUE_CITY) <= 26))
//            .bankItem(new NewBankItem( ItemID.GAS_MASK,1,()->Game.getSetting(Constants.PLAGUE_CITY) >= 1))
//            .bankItem(new NewBankItem( ItemID.PICTURE,1,()->Game.getSetting(Constants.PLAGUE_CITY) <= 22))
//            .bankItem(new NewBankItem( ItemID.WARRANT,1,()->Game.getSetting(Constants.PLAGUE_CITY) <= 28))
//            .bankItem(new NewBankItem( ItemID.A_SMALL_KEY,1,()->Game.getSetting(Constants.PLAGUE_CITY) <= 28))
//            .bankItem(new NewBankItem( ItemID.VARROCK_TELEPORT,0,()->Game.getSetting(Constants.PLAGUE_CITY) <= 28))
//            .bankItem(new NewBankItem( ItemCollections.getSkillNecklaces(),0,()->Game.getSetting(Constants.PLAGUE_CITY) <= 28))
//            .bankItem(new NewBankItem(ItemCollections.getAmuletsOfGlories(),0,()->Game.getSetting(Constants.PLAGUE_CITY) <= 28))
//            .bankItem(new NewBankItem(ItemCollections.getRingsOfWealth(),1,()->Game.getSetting(Constants.PLAGUE_CITY) <= 28))
//            .build();
//
//
//
//    @Override
//    public Priority priority() {
//        return Priority.HIGH;
//    }
//
//    @Override
//    public boolean validate() {
//        return initialCheck && Vars.runtimeSettings.shouldTrainMining && Game.getSetting(Constants.PLAGUE_CITY) <= 28 && actualMining < goalMining;
//    }
//
//    @Override
//    public String toString() {
//        return "Doing Plague City";
//    }
//
//    @Override
//    public void execute() {
//        while (!start) {
//            if (!plagueItems.hasRequiredItems()) {
//                if (!plagueItems.execute()) {
//                    Logging.debug("Banking Event Failed");
//                    runningPrep = true;
//                    runningList = false;
//                    shouldBuyItems = true;
//                    break;
//                }
//            } else {
//                    Logging.debug("We have the required items");
//                    start = true;
//                }
//        }
//        if (start) {
//            switch (Game.getSetting(Constants.PLAGUE_CITY)) {
//                case 0, 28 -> {
//                    Interaction.handleQuestNPC("Edmond", Constants.EDMOND_TILE, "What's happened to her?", "Yes.");
//                }
//                case 1 -> {
//                    //TALK TO ALRENA
//                    Interaction.handleQuestNPC("Alrena", Constants.ALRENA_TILE);
//                }
//                case 2 -> {
//                    //GRAB PICTURE AND THEN TALK TO EDMOND
//                    if (getPictureOfElena()) {
//                        Interaction.handleQuestNPC("Edmond", Constants.MUD_PATCH_TILE);
//                    }
//                }
//                case 3, 4, 5, 6 -> {
//                    //USE WATER ON MUD PATCH1
//                    getPictureOfElena();
//                    if (Player07.distanceTo(Constants.MUD_PATCH_TILE) < 5) {
//                        Interaction.selectItem(Constants.BUCKET_OF_WATER);
//                        Interaction.clickObject(Constants.MUD_PATCH);
//                        Sleep.until(()->Game.getSelectedItemIndex() == 0);
//                    } else {
//                        Traversing.walkTo(Constants.MUD_PATCH_TILE);
//                    }
//
//                }
//
//                case 7 -> {
//                    //GET PICTURE THEN DIG
//                    getPictureOfElena();
//                    if (Player07.distanceTo(Constants.MUD_PATCH_TILE) < 5) {
//                        Interaction.selectItem(Constants.SPADE);
//                        Interaction.clickObject(Constants.MUD_PATCH);
//                        Sleep.until(()->Constants.UNDERGROUND.contains(Player07.getPosition()));
//                    } else {
//                        Traversing.walkTo(Constants.MUD_PATCH_TILE);
//                    }
//
//                }
//                case 8 -> {
//                    //ATTEMPT TO OPEN GRILL
//                    if (Constants.UNDERGROUND.contains(Player07.getPosition())) {
//                        Logging.debug("Underground contains player", Constants.UNDERGROUND.contains(Player07.getPosition()));
//                        if (RSVarBit.get(Constants.HAS_TRIED_TO_OPEN_GRILL).getValue() != 1) {
//                            if (Interaction.handleQuestNPC("Edmond", Constants.EDMOND_UNDERGROUND, 0)) {
//                                Traversing.walkTo(Constants.PIPE_TILE,0);
//                                Sleep.until(()->Player07.distanceTo(Constants.PIPE_TILE) < 10);
//                            }
//                            if (Player07.distanceTo(Constants.PIPE_TILE) < 5) {
//                                Logging.debug("Clicking grill");
//                                Interaction.clickObject(Constants.GRILL);
//                                Interaction.handleContinue();
//                            }
//                        }
//                        if (RSVarBit.get(Constants.HAS_TRIED_TO_OPEN_GRILL).getValue() == 1) {
//                            Traversing.walkTo(Constants.PIPE_TILE, 0);
//                            Sleep.until(()->Player07.distanceTo(Constants.PIPE_TILE) < 10);
//                            if (Player07.distanceTo(Constants.PIPE_TILE) < 10) {
//                                Interaction.selectItem(Constants.ROPE);
//                                Interaction.clickObject(Constants.GRILL);
//                                Sleep.until(()->Inventory07.getCount(Constants.ROPE) == 0);
//                            }
//                        }
//                    } else {
//                        getPictureOfElena();
//                        traverseMudPatch();
//                    }
//                }
//                case 9 -> {
//                    //PULL OFF GRILL
//                    if (!Constants.UNDERGROUND.contains(Player07.getPosition())) {
//                        getPictureOfElena();
//                        traverseMudPatch();
//                    } else {
//                        Interaction.handleQuestNPC("Edmond", Constants.EDMOND_UNDERGROUND, 0);
//                        Sleep.until(()->Game.getSetting(Constants.PLAGUE_CITY) != 9, 10000);
//                    }
//                }
//                case 10 -> {
//                    //ENTER WEST ARDOUGNE
//                    getPictureOfElena();
//                    equipGasMask();
//                    if (!isInWestArdougne()) {
//                        if(!traversePipe()){
//                            traverseMudPatch();
//                        }
//                    } else {
//                        if (Interaction.handleQuestNPC("Jethick", Constants.JETHICK_TILE, 0, "Yes, I'll return it for you.")) {
//                            Interaction.handleQuestNPC("Martha Rehnison", Constants.MARTHAS_HOUSE);
//                        }
//                        Sleep.until(()->Game.getSetting(Constants.PLAGUE_CITY) != 10);
//                    }
//                }
//                case 20, 21 -> {
//                    getPictureOfElena();
//                    equipGasMask();
//                    if (!isInWestArdougne()) {
//                        if(!traversePipe()){
//                            traverseMudPatch();
//                        }
//
//                    } else {
//                        //GO TO MARTHAS HOUSE
//                        Interaction.handleQuestNPC("Martha Rehnison", Constants.MARTHAS_HOUSE);
//                    }
//                }
//                case 22 -> {
//                    //TALK TO MILLI
//                    getPictureOfElena();
//                    equipGasMask();
//                    if (!isInWestArdougne()) {
//                        if(!traversePipe()){
//                            traverseMudPatch();
//                        }
//                    } else {
//                        Interaction.handleQuestNPC("Milli Rehnison", Constants.UPSTAIRS_MARTHAS_HOUSE);
//                    }
//                }
//                case 23 -> {
//                    //GO TO PLAGUE HOUSE
//                    equipGasMask();
//                    if (!isInWestArdougne()) {
//                        if(!traversePipe()){
//                            traverseMudPatch();
//                        }
//                    } else {
//                        if (Traversing.walkTo(Constants.OUTSIDE_PLAGUE_HOUSE)) {
//                            if (Interaction.clickObject(Constants.PLAGUE_DOOR)) {
//                                Sleep.until(NPCInteraction::isConversationWindowUp);
//                                NPCInteraction.handleConversation("I fear not a mere plague.", "I want to check anyway.");
//                            }
//                        }
//                    }
//                }
//                case 24 -> {
//                    //SPEAK TO CLERK
//                    equipGasMask();
//                    if (!isInWestArdougne()) {
//                        if(!traversePipe()){
//                            traverseMudPatch();
//                        }
//                    } else {
//                        Interaction.handleQuestNPC("Clerk", Constants.CLERK_TILE, 0, "I need permission to enter a plague house.", "This is urgent though! Someone's been kidnapped!");
//                    }
//                }
//                case 25 -> {
//                    //TALK TO BRAVEK
//                    equipGasMask();
//                    if (!isInWestArdougne()) {
//                        if(!traversePipe()){
//                            traverseMudPatch();
//                        }
//                    } else {
//                        Interaction.handleQuestNPC("Bravek", Constants.BRAVEK_TILE, 0, "This is really important though!", "Do you know what's in the cure?", "They won't listen to me!");
//                    }
//                }
//                case 26 -> {
//                    //CREATE HANGOVER CURE
//                    equipGasMask();
//                    if (!isInWestArdougne()) {
//                        if(!traversePipe()){
//                            traverseMudPatch();
//                        }
//                    } else {
//                        Interaction.combineItems(Constants.BUCKET_OF_MILK, Constants.CHOCOLATE_DUST);
//                        Interaction.handleContinue();
//                        Sleep.until(()->Inventory07.getCount(Constants.BUCKET_OF_CHOCOLATE_MILK) > 0);
//                        Interaction.combineItems(Constants.BUCKET_OF_CHOCOLATE_MILK, Constants.SNAPE_GRASS);
//                        Interaction.handleContinue();
//                        Sleep.until(()->Inventory07.getCount(Constants.HANGOVER_CURE) > 0);
//                    }
//                    if (Inventory07.getCount(Constants.HANGOVER_CURE) > 0) {
//                        Interaction.handleQuestNPC("Bravek", Constants.BRAVEK_TILE, 0, "This is really important though!", "Do you know what's in the cure?", "They won't listen to me!");
//                    }
//                }
//
//                case 27 -> {
//                    equipGasMask();
//                    if (!isInWestArdougne() && !isInDownstairsPlagueHouse()) {
//                        if(!traversePipe()){
//                            traverseMudPatch();
//                        }
//                    } else {
//                        if (!Constants.INSIDE_PLAGUE_HOUSE.contains(Player07.getPosition()) && !Constants.DOWNSTAIRS_PLAGUE_HOUSE.contains(Player07.getPosition()) && Traversing.walkTo(Constants.OUTSIDE_PLAGUE_HOUSE)) {
//                            if (Interaction.clickObject(Constants.PLAGUE_DOOR)) {
//                                Sleep.until(()->!Player07.isMoving());
//                                NPCInteraction.handleConversation();
//                                Sleep.until(()->Constants.INSIDE_PLAGUE_HOUSE.contains(Player07.getPosition()));
//                            }
//                        }
//                        if (Constants.INSIDE_PLAGUE_HOUSE.contains(Player07.getPosition())) {
//                            if (Inventory07.getCount(Constants.A_SMALL_KEY) == 0) {
//                                Interaction.clickObject(Constants.BARREL);
//                                Sleep.until(()->Inventory07.getCount(Constants.A_SMALL_KEY) > 0);
//                            }
//                            Interaction.handleContinue();
//                            if (Inventory07.getCount(Constants.A_SMALL_KEY) > 0) {
//                                Interaction.clickObject(Constants.SPOOKY_STAIRS);
//                                Sleep.until(()->Constants.DOWNSTAIRS_PLAGUE_HOUSE.contains(Player07.getPosition()));
//                            }
//                        }
//                        if (Constants.DOWNSTAIRS_PLAGUE_HOUSE.contains(Player07.getPosition())) {
//                            if (Interaction.clickObject(Constants.DOOR)) {
//                                General.sleep(1000);
//                                Sleep.until(()->!(Player07.isAnimating() && Player07.isMoving()));
//                            }
//                        }
//                        if (Constants.PLAGUE_HOUSE_CELL.contains(Player07.getPosition())) {
//                            if (Interaction.handleQuestNPC("Elena")) {
//                                Sleep.until(()->Game.getSetting(Constants.PLAGUE_CITY) != 27);
//                            }
//                        }
//                    }
//                }
//            }
//        }
//    }
//
//    private boolean isInDownstairsPlagueHouse() {
//        return Constants.DOWNSTAIRS_PLAGUE_HOUSE.contains(Player07.getPosition()) || Constants.PLAGUE_HOUSE_CELL.contains(Player07.getPosition());
//    }
//
//    private boolean isInWestArdougne() {
//        return Constants.WEST_ARDOUGNE.contains(Player07.getPosition());
//    }
//
//    private boolean equipGasMask() {
//        if (!Equipment.isEquipped(Constants.GAS_MASK)) {
//            Interaction.selectItem(Constants.GAS_MASK, "Wear");
//        }
//        return Equipment.isEquipped(Constants.GAS_MASK);
//    }
//
//    private boolean getPictureOfElena() {
//        if (Constants.UPSTAIRS_ALRENA_HOUSE.contains(Player07.getPosition())) {
//            Interaction.clickObject(Constants.STAIRCASE);
//            Sleep.until(()->!Constants.UPSTAIRS_ALRENA_HOUSE.contains(Player07.getPosition()));
//        }
//        if (Inventory07.getCount(Constants.PICTURE_OF_ELENA) > 0) {
//            return true;
//        }
//            if (Traversing.walkTo(Constants.PICTURE_TILE)) {
//                Interaction.pickupItem(Constants.PICTURE_OF_ELENA);
//                Sleep.until(()->Inventory07.getCount(Constants.PICTURE_OF_ELENA) > 0);
//            }
//        return Inventory07.getCount(Constants.PICTURE_OF_ELENA) > 0;
//    }
//
//    private boolean traverseMudPatch() {
//        if (Traversing.walkTo(Constants.MUD_PATCH_TILE)) {
//            Interaction.clickObject(Constants.MUD_PATCH);
//            Sleep.until(()->Constants.UNDERGROUND.contains(Player07.getPosition()));
//        }
//        return Constants.UNDERGROUND.contains(Player07.getPosition());
//    }
//
//    private boolean traversePipe() {
//        if (!Constants.UNDERGROUND.contains(Player07.getPosition())) {
//            return false;
//        }
//        while (!isInWestArdougne()) {
//            if (Traversing.walkTo(Constants.PIPE_TILE, 0)) {
//                Interaction.clickObject(Constants.PIPE);
//                Sleep.until(this::isInWestArdougne);
//            }
//        }
//        return isInWestArdougne();
//    }
//
//}
