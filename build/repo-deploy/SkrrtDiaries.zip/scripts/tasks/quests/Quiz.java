package scripts.tasks.quests;

import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api2007.Game;
import org.tribot.api2007.Interfaces;
import org.tribot.api2007.Skills;
import org.tribot.api2007.types.RSArea;
import org.tribot.api2007.types.RSInterface;
import org.tribot.api2007.types.RSVarBit;
import scripts.data.Constants;
import scripts.data.agility.Course;
import scripts.data.agility.Obstacle;
import scripts.data.kudos.Exhibit;
import scripts.skrrt_api.task.Priority;
import scripts.skrrt_api.task.Task;
import scripts.skrrt_api.util.functions.Interaction;
import scripts.skrrt_api.util.functions.Logging;
import scripts.skrrt_api.util.functions.Player07;
import scripts.skrrt_api.util.functions.Traversing;
import scripts.skrrt_api.util.numbers.Reactions;

import java.util.ArrayList;

import static scripts.data.Vars.*;

public class Quiz implements Task {

    private boolean start;
    private RSArea[] exhibitAreas = {Constants.MUSEUM_ROOM1,Constants.MUSEUM_ROOM2,Constants.MUSEUM_ROOM3,Constants.MUSEUM_ROOM4};


    @Override
    public String toString() {
        return "Completing Natural History Quiz";
    }

    @Override
    public Priority priority() {
        return Priority.HIGH;
    }

    @Override
    public boolean validate() {
        return initialCheck && runtimeSettings.shouldKudos && Game.getSetting(Constants.QUIZ_SETTING) >= 0;
    }

    @Override
    public void execute() {
        if(Game.getSetting(Constants.QUIZ_SETTING) == 0){
            currentTask = "Starting Quiz";
            Interaction.handleQuestNPC("Orlando Smith",Constants.ORLANDO_AREA,"Sure thing.");
        } else {
            boolean needNextRoom = Exhibit.needNextRoom();
            if(kudos >= 28){
                Interaction.handleQuestNPC("Orlando Smith",Constants.ORLANDO_AREA,"Sure thing.");

            }
            if(needNextRoom || (!Constants.MUSEUM_ROOM1.contains(Player07.getPosition())||!Constants.MUSEUM_ROOM2.contains(Player07.getPosition())||!Constants.MUSEUM_ROOM3.contains(Player07.getPosition())||!Constants.MUSEUM_ROOM4.contains(Player07.getPosition()))){
                RSArea nextRoom = Exhibit.getNextRoom();
                if(nextRoom!=null){
                    Traversing.walkTo(nextRoom);
                }
            }

                while(Game.getSetting(Constants.QUIZ_SETTING) > 0){
                    if(!Interfaces.isInterfaceSubstantiated(Constants.QUIZ_MASTER)){
                        General.sleep(Reactions.getNormal());
                        if(Interaction.clickObject(Exhibit.getNextPlaque())){
                            Logging.message("Attempting to click plaque");
                            Timing.waitCondition(()->Interfaces.isInterfaceSubstantiated(Constants.QUIZ_MASTER),Reactions.getSemiAFK());
                        } else {
                            RSArea currentRoom = Exhibit.getCurrentRoom();
                            if(currentRoom != null){
                                Traversing.walkTo(currentRoom);
                            }
                        }
                    }else{
                        RSInterface option = Exhibit.getOption();
                        Logging.debug("Interface is substantiated.");
                        if(option!= null){
                            option.click();
                            Timing.waitCondition(()->!Interfaces.isInterfaceSubstantiated(Constants.QUIZ_MASTER),Reactions.getSemiAFK());
                        }

                    }
                    if (Exhibit.getNextPlaque() == 0){
                        RSArea nextRoom = Exhibit.getNextRoom();
                        if(nextRoom!=null){
                            Traversing.walkTo(nextRoom);
                        } else {
                            currentTask = "Turning in Quiz";
                            Interaction.handleQuestNPC("Orlando Smith",Constants.ORLANDO_AREA,"Sure thing.");
                        }
                    }
                    kudos = RSVarBit.get(Constants.KUDOS_VARBIT).getValue();
                    General.sleep(Reactions.getNormal());
                }
            }
        }


    }

