//package scripts.tasks.quests;
//
//import org.tribot.api2007.Game;
//import scripts.data.Constants;
//import scripts.data.Vars;
//import scripts.skrrt_api.events.BankEvent;
//import scripts.skrrt_api.task.Priority;
//import scripts.skrrt_api.task.Task;
//import scripts.skrrt_api.util.functions.Interaction;
//import scripts.skrrt_api.util.functions.Logging;
//import scripts.skrrt_api.util.items.ItemCollections;
//import scripts.skrrt_api.util.items.ItemID;
//import scripts.skrrt_api.util.items.NewBankItem;
//import scripts.skrrt_api.util.npc.NpcID;
//
//import static scripts.data.Vars.*;
//
//public class RuneMysteries implements Task {
//    boolean start = false;
//
//    BankEvent runeMysteries = BankEvent.builder()
//            .bankItem(new NewBankItem(ItemID.VARROCK_TELEPORT, 0))
//            .bankItem(new NewBankItem(ItemID.LUMBRIDGE_TELEPORT, 0))
//            .bankItem(new NewBankItem(ItemID.RESEARCH_PACKAGE, 1, () -> Game.getSetting(Constants.RUNE_MYSTERIES) >= 2 && Game.getSetting(Constants.RUNE_MYSTERIES) < 5))
//            .bankItem(new NewBankItem(ItemID.NOTES, 1, () -> Game.getSetting(Constants.RUNE_MYSTERIES) == 5))
//            .bankItem(new NewBankItem(ItemCollections.getNecklacesOfPassage(), 1))
//            .build();
//
//
//    @Override
//    public Priority priority() {
//        return Priority.HIGH;
//    }
//
//    @Override
//    public boolean validate() {
//        return initialCheck && Vars.runtimeSettings.isShouldRuneMysteries() && Game.getSetting(Constants.RUNE_MYSTERIES) < 6;
//    }
//
//    @Override
//    public String toString() {
//        return "Doing Rune Mysteries";
//    }
//
//    @Override
//    public void execute() {
//        while (!start) {
//            if (!runeMysteries.execute()) {
//                Logging.debug("Banking Event Failed");
//                runningPrep = true;
//                runningList = false;
//                shouldBuyItems = true;
//                break;
//            } else {
//                start = true;
//            }
//        }
//        if (start) {
//            switch (Game.getSetting(Constants.RUNE_MYSTERIES)) {
//                case 0 -> {
//                    currentTask = "Walking to Duke Horacio";
//                    Interaction.handleQuestNPC(NpcID.DUKE_HORACIO, Constants.DUKE_AREA, "Have you any quests for me?", "Yes.");
//                }
//                case 1, 2, 5 -> {
//                    currentTask = "Walking to Sedridor";
//                    Interaction.handleQuestNPC(NpcID.SEDRIDOR, Constants.SEDRIDOR_AREA, "I'm looking for the head wizard.", "Ok, here you are.", "Yes, certainly.");
//                }
//                case 3, 4 -> {
//                    currentTask = "Walking to Aubury";
//                    Interaction.handleQuestNPC(NpcID.AUBURY, Constants.AUBURY_AREA, "I have been sent here with a package for you.");
//                }
//            }
//        }
//
//    }
//}
