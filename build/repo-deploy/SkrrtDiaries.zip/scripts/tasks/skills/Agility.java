package scripts.tasks.skills;

import org.tribot.api.General;
import org.tribot.api2007.Skills;
import scripts.data.Constants;
import scripts.data.agility.Course;
import scripts.data.agility.Obstacle;
import scripts.skrrt_api.task.Priority;
import scripts.skrrt_api.task.Task;
import scripts.skrrt_api.util.functions.Logging;
import scripts.skrrt_api.util.functions.Traversing;
import scripts.skrrt_api.util.numbers.Reactions;

import java.util.ArrayList;

import static scripts.data.Vars.*;

public class Agility implements Task {

    private boolean start;
    private Course gnome = new Course("Gnome Agility", 15,  Constants.LOG_TILE, false, Constants.NECKLACE_OF_PASSAGE,
            new Obstacle[]{
                    new Obstacle("Log balance", "Walk-across", Constants.LOG_TILE),
                    new Obstacle("Obstacle net", "Climb-over", Constants.FIRST_NET),
                    new Obstacle("Tree branch", "Climb", Constants.FIRST_BRANCH),
                    new Obstacle("Balancing rope", "Walk-on", Constants.CLIMBING_ROPE),
                    new Obstacle("Tree branch", "Climb-down", Constants.SECOND_BRANCH),
                    new Obstacle("Obstacle net", "Climb-over", Constants.SECOND_NET),
                    new Obstacle("Obstacle pipe", "Squeeze-through", Constants.TUNNEL)});

    private Course draynor = new Course("Draynor Rooftop", 21, Constants.DRAYNOR_START, true, Constants.AMULET_OF_GLORY,
            new Obstacle[]{

                    new Obstacle("Rough wall","Climb",Constants.DRAYNOR_START),
                    new Obstacle("Tightrope","Cross",Constants.FIRST_TIGHT_ROPE_AREA),
                    new Obstacle("Tightrope","Cross",Constants.SECOND_TIGHT_ROPE_AREA),
                    new Obstacle("Narrow wall","Balance",Constants.NARROW_WALL_AREA),
                    new Obstacle("Wall","Jump-up",Constants.WALL_AREA),
                    new Obstacle("Gap","Jump",Constants.GAP_AREA),
                    new Obstacle("Crate", "Climb-down", Constants.CRATE_AREA),

            });
    private ArrayList<Course> courses = new ArrayList<>() {
        {
            add(gnome);
            add(draynor);
        }
    };

    @Override
    public String toString() {
        return "Training Agility";
    }

    @Override
    public Priority priority() {
        return Priority.MEDIUM;
    }

    @Override
    public boolean validate() {
        return initialCheck && runtimeSettings.shouldTrainAgility && actualAgility < goalAgility;
    }

    @Override
    public void execute() {
        Course currentCourse = Course.getCurrentCourse(courses);
        actualAgility = Skills.SKILLS.AGILITY.getActualLevel();
        if (currentCourse != null) {
            currentTask = currentCourse.getName();
            if (!start) {
                Logging.message("Diaries","Training Agility","Current Agility Level: " + actualAgility,"Goal Agility Level: " + goalAgility, "Current Course: " + currentCourse.getName());

                if(currentCourse.withdrawTeleports(courses)){
                    General.sleep(Reactions.getAgilitySleep());
                    Traversing.walkTo(currentCourse.getStartArea());
                }
                start = true;
            }
            while (start) {
                currentCourse.doCourse();
                if(currentCourse.hasFallen()){
                    Traversing.walkTo(currentCourse.getStartArea());
                }
                if(Skills.getActualLevel(Skills.SKILLS.AGILITY) >= currentCourse.getStoppingLevel()){
                    currentCourse = Course.getCurrentCourse(courses);
                    start = false;
                }
            }

        }
    }
}
