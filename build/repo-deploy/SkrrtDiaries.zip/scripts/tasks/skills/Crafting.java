//package scripts.tasks.skills;
//
//import org.tribot.api.General;
//import org.tribot.api.Timing;
//import org.tribot.api2007.Interfaces;
//import org.tribot.api2007.NPCChat;
//import org.tribot.api2007.Skills;
//import scripts.data.Constants;
//import scripts.data.crafting.CraftableItems;
//import scripts.skrrt_api.events.BankEvent;
//import scripts.skrrt_api.events.GrandExchangeEvent;
//import scripts.skrrt_api.task.Priority;
//import scripts.skrrt_api.task.Task;
//import scripts.skrrt_api.util.antiban.Antiban;
//import scripts.skrrt_api.util.functions.*;
//import scripts.skrrt_api.util.items.ItemID;
//import scripts.skrrt_api.util.items.NewBankItem;
//import scripts.skrrt_api.util.numbers.Reactions;
//
//import static scripts.data.Vars.*;
//
//public class Crafting implements Task {
//
//    private boolean start = false;
//
//    BankEvent craftingItems = BankEvent.builder()
//            .bankItem(new NewBankItem(ItemID.NEEDLE, 0))
//            .bankItem(new NewBankItem(ItemID.LEATHER, 26))
//            .bankItem(new NewBankItem(ItemID.THREAD, 0))
//            .build();
//
//    @Override
//    public Priority priority() {
//        return Priority.MEDIUM;
//    }
//
//    @Override
//    public String toString() {
//        return "Training Crafting";
//    }
//
//    @Override
//    public boolean validate() {
//        return initialCheck && runtimeSettings.isShouldTrainCrafting() && actualCrafting < goalCrafting;
//    }
//
//    @Override
//    public void execute() {
//        actualCrafting = Skills.SKILLS.CRAFTING.getActualLevel();
//        if (!start) {
//            Logging.message("Diaries", "Training Crafting", "Current Crafting Level: " + actualCrafting, "Goal Crafting Level: " + goalCrafting, "Current Item: " + CraftableItems.getCurrentCraftingItem());
//            start = true;
//        }
//        if (!craftingItems.hasRequiredItems() && Inventory07.getCount(ItemID.LEATHER)==0) {
//            if (!craftingItems.execute()) {
//                Logging.debug("Banking Event Failed");
//                runningPrep = true;
//                runningList = false;
//                shouldBuyItems = true;
//            }
//        } else {
//            if (!Player07.isAnimating() && Inventory07.getCount(Constants.LEATHER) > 0 && Inventory07.getCount(Constants.THREAD) > 0) {
//                CraftableItems currentItem = CraftableItems.getCurrentCraftingItem();
//                currentTask = "Crafting " + currentItem;
//                if (currentItem != null) {
//                    if (!Interfaces.isInterfaceSubstantiated(270)) {
//                        if (!Timing.waitCondition(Player07::isAnimating, 4000)) {
//                            Interaction.handleContinue();
//                            if(Interaction.combineItems("Leather", "Needle")){
//                                Sleep.until(()->Interfaces.isInterfaceSubstantiated(270));
//                            }
//                        }
//                    }
//                    if (Interfaces.isInterfaceSubstantiated(270)) {
//                        Interaction.makeAll(270, currentItem.getName());
//                        Antiban.timedActions();
//                        Antiban.generateTrackers((int) Reactions.getAFK());
//                        Sleep.until(()->Interfaces.isInterfaceSubstantiated(NPCChat.getClickContinueInterface()) || Inventory07.getCount(Constants.LEATHER) == 0);
//                    }
//                }
//
//            }
//        }
//    }
//}
//
