//package scripts.tasks.skills;
//
//import org.tribot.api.General;
//import org.tribot.api.Timing;
//import org.tribot.api.input.Mouse;
//import org.tribot.api2007.NPCs;
//import org.tribot.api2007.Skills;
//import org.tribot.api2007.ext.Filters;
//import org.tribot.api2007.types.RSItem;
//import org.tribot.api2007.types.RSNPC;
//import scripts.data.Constants;
//import scripts.entityselector.Entities;
//import scripts.entityselector.finders.prefabs.ItemEntity;
//import scripts.skrrt_api.events.BankEvent;
//import scripts.skrrt_api.task.Priority;
//import scripts.skrrt_api.task.Task;
//import scripts.skrrt_api.util.antiban.Antiban;
//import scripts.skrrt_api.util.functions.*;
//import scripts.skrrt_api.util.items.ItemID;
//import scripts.skrrt_api.util.items.NewBankItem;
//import scripts.skrrt_api.util.numbers.Reactions;
//
//import java.util.Arrays;
//
//import static scripts.data.Vars.*;
//
//public class Fishing implements Task {
//    boolean start = false;
////    BankEvent fishingItems = BankEvent.builder()
////            .bankItem(new NewBankItem(ItemID.SMALL_FISHING_NET, 1))
////            .bankItem(new NewBankItem(ItemID.CAMELOT_TELEPORT, 0))
////            .build();
//
//
//    @Override
//    public Priority priority() {
//        return Priority.HIGH;
//    }
//
//    @Override
//    public String toString() {
//        return "Training Fishing";
//    }
//
//    @Override
//    public boolean validate() {
//        return initialCheck && runtimeSettings.shouldTrainFishing && actualFishing < goalFishing;
//    }
//
//    @Override
//    public void execute() {
//
//        actualFishing = Skills.SKILLS.FISHING.getActualLevel();
//
//        while (!start) {
//            if (!fishingItems.hasRequiredItems()) {
//                if (!fishingItems.execute()) {
//                    Logging.debug("Banking Event Failed");
//                    runningPrep = true;
//                    runningList = false;
//                    shouldBuyItems = true;
//                    break;
//                }
//            } else {
//                Logging.debug("We have the required items");
//                start = true;
//            }
//            if (start) {
//                if (!Constants.FISHING_AREA.contains(Player07.getPosition())) {
//                    currentTask = "Walking to Catherby";
//                    Traversing.walkTo(Constants.FISHING_AREA);
//                } else {
//                    Interaction.handleContinue();
//                    if (!Timing.waitCondition(Player07::isAnimating, 5000) && !Inventory07.isFull()) {
//                        RSNPC spot = Arrays.stream(NPCs.getAll()).filter(Filters.NPCs.actionsContains("Small Net")).findFirst().orElse(null);
//                        if (spot != null) {
//                            Traversing.smartWalk(spot);
//                            Logging.message("Attempting to click fishing spot");
//                            if (Interaction.clickNPC(spot)) {
//                                currentTask = "Interacting with Fishing Spot";
//                                int decision = Reactions.getDecision(2);
//                                General.sleep(Reactions.getNormal());
//                                if (decision > 100 && Mouse.isInBounds()) {
//                                    Mouse.leaveGame(true);
//                                } else {
//                                    Antiban.timedActions();
//                                }
//                                Antiban.generateTrackers((int) Reactions.getAFK());
//                            }
//                        } else {
//                            Traversing.smartWalk(Constants.FISHING_AREA.getRandomTile());
//                        }
//                    } else {
//                        General.sleep(Reactions.getNormal());
//                    }
//                    if (Inventory07.isFull()) {
//                        General.sleep(Reactions.getNormal());
//                        currentTask = "Dropping raw fish";
//                        RSItem[] raw = Entities.find(ItemEntity::new)
//                                .nameContains("Raw")
//                                .getResults();
//                        if (raw.length > 0) {
//                            Inventory07.drop(raw);
//                        }
//                    }
//                }
//            }
//        }
//    }
//}
//
