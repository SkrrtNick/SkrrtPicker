package scripts.tasks.skills;

import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api2007.NPCChat;
import org.tribot.api2007.Skills;
import org.tribot.api2007.types.RSItem;
import org.tribot.api2007.types.RSObject;
import org.tribot.api2007.types.RSPlayer;
import scripts.data.Constants;
import scripts.entityselector.Entities;
import scripts.entityselector.finders.prefabs.ItemEntity;
import scripts.skrrt_api.task.Priority;
import scripts.skrrt_api.task.Task;
import scripts.skrrt_api.util.functions.*;
import scripts.skrrt_api.util.numbers.Reactions;

import static scripts.data.Vars.*;

public class Thieving implements Task {
    boolean start = false;

    @Override
    public Priority priority() {
        return Priority.HIGH;
    }

    @Override
    public String toString() {
        return "Training Thieving";
    }

    @Override
    public boolean validate() {
        return initialCheck && !shouldBuyItems && runtimeSettings.shouldTrainThieving && actualThieving < goalThieving;
    }

    @Override
    public void execute() {
        actualThieving = Skills.SKILLS.THIEVING.getActualLevel();
        if (!start) {
            Logging.message("Training Thieving to: " + goalThieving);
            start = true;
        }
        if (!Constants.MEN_AREA.contains(Player07.getPosition()) && Player07.distanceTo(Constants.MEN_AREA.getRandomTile()) > 10) {
            if (Banking07.openBank()) {
                if (!Inventory07.isEmpty()) {
                    Banking07.depositAll();
                }
                if (Player07.distanceTo(Constants.MEN_AREA.getRandomTile()) > 50) {
                    Banking07.withdrawItems(true, 0, Constants.AMULET_OF_GLORY);
                    Timing.waitCondition(() -> Inventory07.getCount(Constants.AMULET_OF_GLORY) > 0, Reactions.getNormal());
                }
            }
            Traversing.walkTo(Constants.MEN_AREA);
        }
        RSItem coinPouch = Entities.find(ItemEntity::new)
                .idEquals(Constants.COIN_POUCH)
                .getFirstResult();
        int vertexCount = Player07.getRSPlayer().getModel().getVertexCount();
        if (vertexCount > 300) {
            Logging.message("Oh dear, we are stunned!");
            int decision = Reactions.getDecision(2);
            if (decision < 100) {
                if (coinPouch != null) {
                    coinPouch.click("Open-all");
                    Timing.waitCondition(() -> Inventory07.getCount(Constants.COIN_POUCH) == 0, Reactions.getNormal());
                }
            } Timing.waitCondition(() -> Player07.getRSPlayer().getModel().getVertexCount() < 300, Reactions.getNormal());
        }
        if (Interaction.npcExists("Man") && Inventory07.getCount(Constants.COIN_POUCH) < 28) {
            Interaction.handleContinue();
            General.sleep(Reactions.getNormal());
            currentTask = "Pickpocketing Man";
            Interaction.clickNPC("Man", "Pickpocket");
        } else if (Inventory07.getCount(Constants.COIN_POUCH) == 28) {
             coinPouch = Entities.find(ItemEntity::new)
                    .idEquals(Constants.COIN_POUCH)
                    .getFirstResult();
            if (coinPouch != null) {
                coinPouch.click("Open-all");
                Timing.waitCondition(() -> Inventory07.getCount(Constants.COIN_POUCH) == 0, Reactions.getNormal());
            }
        }
    }
}