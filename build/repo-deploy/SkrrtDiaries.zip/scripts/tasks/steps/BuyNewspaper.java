package scripts.tasks.steps;

import org.tribot.api.General;
import scripts.data.Constants;
import scripts.data.Diaries;
import scripts.skrrt_api.task.Priority;
import scripts.skrrt_api.task.Task;
import scripts.skrrt_api.util.functions.*;
import scripts.skrrt_api.util.items.BankItem;

import java.util.ArrayList;

import static scripts.data.Vars.*;
import static scripts.data.Vars.shouldWithdrawItems;

public class BuyNewspaper implements Task {
    boolean start = false;

    @Override
    public Priority priority() {
        return null;
    }

    @Override
    public boolean validate() {
        return initialCheck && runtimeSettings.shouldBuyNewspaper && !Diaries.BUYNEWSPAPER.isCompleted();
    }

    @Override
    public void execute() {
        ArrayList<BankItem> bankItems = new ArrayList<>() {
            {
                add(new BankItem(Constants.VARROCK_TELEPORT,0,true,Diaries.BUYNEWSPAPER.isCompleted(),Player07.distanceTo(Constants.NEWSPAPER_AREA.getRandomTile())<50));
                add(new BankItem(Constants.COINS,0,true,Diaries.BUYNEWSPAPER.isCompleted()));
            }
        };
        while (!start) {
            if (!Inventory07.hasRequired(bankItems)) {
                Logging.debug("Doesn't have the required items in the inventory, will check bank");
                shouldWithdrawItems = true;
                runningPrep = true;
                runningList = false;
                break;
            } else {
                start = true;
            }
        }
        //DO TASK
        if(start){
            if(!Constants.NEWSPAPER_AREA.contains(Player07.getPosition())){
                Traversing.walkTo(Constants.NEWSPAPER_AREA);
            } else {
                Interaction.handleQuestNPC("Benny","Can I have a newspaper, please?","Sure, here you go...");
                Sleep.until(Diaries.BUYNEWSPAPER::isCompleted);
            }
        }
    }
}
