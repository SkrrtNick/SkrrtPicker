package scripts.tasks.steps;

import scripts.data.Constants;
import scripts.data.Diaries;
import scripts.skrrt_api.task.Priority;
import scripts.skrrt_api.task.Task;
import scripts.skrrt_api.util.functions.Inventory07;
import scripts.skrrt_api.util.functions.Logging;
import scripts.skrrt_api.util.items.BankItem;

import java.util.ArrayList;

import static scripts.data.Vars.*;

public class CatchTrout implements Task {
    boolean start = false;
    ArrayList<BankItem> bankItems = new ArrayList<>() {
        {
            add(new BankItem(Constants.FLY_FISHING_ROD, 1, true, Diaries.TROUT.isCompleted()));
            add(new BankItem(Constants.FEATHER, 0, true, Diaries.TROUT.isCompleted()));
        }
    };


    @Override
    public String toString() {
        return "Catching Trout";
    }

    @Override
    public Priority priority() {
        return null;
    }

    @Override
    public boolean validate() {
//        return initialCheck && runtimeSettings.shouldCatchTrout && !Diaries.TROUT.isCompleted() && actualFishing >= goalFishing;
    return true;
    }


    @Override
    public void execute() {
        while (!start) {
            if (!Inventory07.hasRequired(bankItems)) {
                Logging.debug("Doesn't have the required items in the inventory, will check bank");
                shouldWithdrawItems = true;
                runningPrep = true;
                runningList = false;
                break;
            } else {
                start = true;
            }
        }
        if (start) {

        }
        //DO TASK
    }
}
