package scripts.tasks.steps;

import scripts.dax_api.api_lib.models.RunescapeBank;
import org.tribot.api.General;
import scripts.data.Constants;
import scripts.data.Diaries;
import scripts.skrrt_api.task.Priority;
import scripts.skrrt_api.task.Task;
import scripts.skrrt_api.util.functions.*;
import scripts.skrrt_api.util.numbers.Reactions;

import static scripts.data.Vars.initialCheck;
import static scripts.data.Vars.runtimeSettings;

public class EnterSoS implements Task {
    private boolean start = false;

    @Override
    public Priority priority() {
        return null;
    }

    @Override
    public boolean validate() {
        return initialCheck && runtimeSettings.shouldSos && !Diaries.STRONGHOLD_OF_SECURITY.isCompleted();
    }

    @Override
    public void execute() {
        while (!start) {
            if (!Inventory07.isEmpty() || !Player07.isNaked()) {
                if (Traversing.walkTo(RunescapeBank.EDGEVILLE.getPosition())) {
                    if (Banking07.openBank()) {
                        Sleep.until(Banking07::isBankLoaded);
                        if(!Player07.isNaked()){
                            Logging.message("Depositing equipment to keep it safe!");
                            Banking07.depositEquipment();
                            Sleep.until(Player07::isNaked);
                        }
                        if (!Inventory07.isEmpty()){
                            Logging.message("Depositing items to keep them safe!");
                            Sleep.until(()->Banking07.depositAll() > 0);
                        }
                        General.sleep(Reactions.getNormal());
                        Banking07.close();
                    }
                }
            } else {
                start = true;
            }
        }
        if (start) {
            if (!Constants.SOS_AREA.contains(Player07.getPosition())) {
                Traversing.walkTo(Constants.SOS_AREA);
                Sleep.until(()->!Player07.isMoving());
            }
        }
    }
}
