package scripts.tasks.steps;

import scripts.skrrt_api.task.Priority;
import scripts.skrrt_api.task.Task;

public class GiveADogABone implements Task {
    @Override
    public Priority priority() {
        return null;
    }

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public void execute() {

    }
}
