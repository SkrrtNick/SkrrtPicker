package scripts.tasks.steps;

import scripts.data.Constants;
import scripts.data.Diaries;
import scripts.skrrt_api.task.Priority;
import scripts.skrrt_api.task.Task;
import scripts.skrrt_api.util.functions.*;
import scripts.skrrt_api.util.items.BankItem;

import java.util.ArrayList;

import static scripts.data.Vars.*;

public class StealTea implements Task {
    private boolean start = false;


    @Override
    public Priority priority() {
        return null;
    }

    @Override
    public boolean validate() {
        return initialCheck && !shouldBuyItems && runtimeSettings.shouldStealTea && !Diaries.TEA.isCompleted() && actualThieving >= goalThieving;
    }

    @Override
    public void execute() {
        while (!start) {
            ArrayList<BankItem> bankItems = new ArrayList<>() {
                {
                    add(new BankItem(Constants.VARROCK_TELEPORT, 0, true, Diaries.TEA.isCompleted(), Player07.distanceTo(Constants.TEA_STALL_AREA.getRandomTile()) < 50));
                }
            };
            if (!Inventory07.hasRequired(bankItems)) {
                Logging.debug("Doesn't have the required items in the inventory, will check bank");
                shouldWithdrawItems = true;
                runningPrep = true;
                runningList = false;
                break;
            } else {
                start = true;
            }
        }
        //DO TASK
        if (start) {
            if (!Constants.TEA_STALL_AREA.contains(Player07.getPosition())) {
                Traversing.walkTo(Constants.TEA_STALL_AREA);
            } else {
                Interaction.clickObject(Constants.TEA_STALL);
                Sleep.until(Diaries.TEA::isCompleted);
            }
        }
    }
}