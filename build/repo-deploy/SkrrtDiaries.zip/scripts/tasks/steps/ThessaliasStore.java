package scripts.tasks.steps;

import org.tribot.api2007.Interfaces;
import scripts.data.Constants;
import scripts.data.Diaries;
import scripts.skrrt_api.task.Priority;
import scripts.skrrt_api.task.Task;
import scripts.skrrt_api.util.functions.*;
import scripts.skrrt_api.util.items.BankItem;

import java.util.ArrayList;

import static scripts.data.Vars.*;

public class ThessaliasStore implements Task {
    private boolean start = false;


    @Override
    public Priority priority() {
        return null;
    }

    @Override
    public boolean validate() {
        return initialCheck && runtimeSettings.shouldThesseliasStore && !Diaries.THESSELIAS_STORE.isCompleted();
    }

    @Override
    public void execute() {
        ArrayList<BankItem> bankItems = new ArrayList<>() {
            {
                add(new BankItem(Constants.VARROCK_TELEPORT, 1, true, Player07.distanceTo(Constants.THESSELIA_AREA.getRandomTile()) < 50));
            }
        };
        while (!start) {
            if (!Inventory07.hasRequired(bankItems)) {
                Logging.debug("Doesn't have the required items in the inventory, will check bank");
                shouldWithdrawItems = true;
                runningPrep = true;
                runningList = false;
                break;
            } else {
                start = true;
            }
        }
        //DO TASK
        if (start) {
            if (!Constants.THESSELIA_AREA.contains(Player07.getPosition())) {
                Traversing.walkTo(Constants.THESSELIA_AREA);
            } else {
                Interaction.clickNPC("Thessalia", "Trade");
                Sleep.until(()->Interfaces.isInterfaceSubstantiated(300));
            }
        }
    }
}
