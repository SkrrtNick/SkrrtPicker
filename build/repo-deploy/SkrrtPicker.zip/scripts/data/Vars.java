package scripts.data;



public class Vars {

    public static double playerSeed = 0;
    public static boolean runningPrep = false;
    public static String status;
    public static String currentTask;
    public static String profileName;
    public static int x,y,z;
    public static Profile runtimeSettings = null;


    //TASK RELATED

}




