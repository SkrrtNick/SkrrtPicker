package scripts.dax_api.walker.models.enums;

public enum Situation {
    COLLISION_BLOCKING,
    DISCONNECTED_PATH,
    NORMAL_PATH_HANDLING,
    PATH_TOO_FAR,
}
