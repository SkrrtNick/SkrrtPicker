//package scripts.core.grandexchange;
//
//import org.tribot.api.DynamicClicking;
//import org.tribot.api.General;
//import org.tribot.api.Timing;
//import org.tribot.api2007.*;
//import org.tribot.api2007.types.*;
//import org.tribot.script.Script;
//import scripts.skrrt_api.events.BankEventV2;
//import scripts.skrrt_api.events.BotEvent;
//import scripts.skrrt_api.events.InventoryEvent;
//
//import scripts.skrrt_api.events.TypingEvent;
//import scripts.skrrt_api.util.functions.Traversing;
//import scripts.skrrt_api.util.items.ExchangeBoxes;
//import scripts.skrrt_api.util.items.GrandExchangeItem;
//
//import java.io.IOException;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Optional;
//
//public class GEEvent extends BotEvent {
//
//    public HashMap<String, GrandExchangeItem> grandExchangeItemHashMap = new HashMap<>();
//
//    BankEventV2 bankEvent;
//
//    RSArea grandExchangeArea = new RSArea(
//            new RSTile[]{
//                    new RSTile(3157, 3494, 0),
//                    new RSTile(3157, 3487, 0),
//                    new RSTile(3162, 3483, 0),
//                    new RSTile(3169, 3483, 0),
//                    new RSTile(3173, 3487, 0),
//                    new RSTile(3173, 3494, 0),
//                    new RSTile(3168, 3498, 0),
//                    new RSTile(3161, 3498, 0)
//            }
//    );
//
//    public GEEvent(Script script, BankEventV2 bankEvent) {
//        super(script);
//        this.bankEvent = bankEvent;
//
//    }
//
//    public GEEvent addReq(String itemName, int id, int qty, int price) {
//        setGrandExchangeItemIDList(itemName, id, qty, price);
//        return this;
//    }
//
//
//    public boolean isPendingOperation() {
//        if (bankEvent.bankCacheHashMap.isEmpty()) {
//            General.println("We need to have a cache first");
//            return false;
//        }
//        for (Map.Entry<String, GrandExchangeItem> grandExchangeList : grandExchangeItemHashMap.entrySet()) {
//            String itemName = grandExchangeList.getKey();
//            int itemID = grandExchangeList.getValue().getId();
//            int itemAmount = grandExchangeList.getValue().getQty();
//            int itemPrice = grandExchangeList.getValue().getPrice();
//            if (!bankEvent.bankCacheHashMap.containsKey(itemName) || (bankEvent.bankCacheHashMap.containsKey(itemName) && bankEvent.bankCacheHashMap.get(itemName).getQty() == 0)) {
//                return true;
//            }
//        }
//        return false;
//    }
//
//    public void setGrandExchangeItemIDList(String itemName, int id, int qty, int price) {
//        grandExchangeItemHashMap.put(itemName, new GrandExchangeItem(itemName, id, qty, price));
//    }
//
//    public void setGrandExchangeItemList(String itemName, int qty, int price) {
//        grandExchangeItemHashMap.put(itemName, new GrandExchangeItem(itemName, qty, price));
//    }
//
//
//    @Override
//    public void step() throws InterruptedException, IOException {
//        if (!grandExchangeArea.contains(me())) {
//            Traversing.walkTo(grandExchangeArea);
//        } else {
//            if (needCoins()) {
//                getCoins();
//            } else if (Banking.isBankScreenOpen()) {
//                Banking.close();
//                Timing.waitCondition(() -> !Banking.isBankScreenOpen(), 4000);
//            } else if (canOpenExchange()) {
//                openGrandExchange();
//            } else {
//                for (Map.Entry<String, GrandExchangeItem> grandExchangeItems : grandExchangeItemHashMap.entrySet()) {
//                    String itemName = grandExchangeItems.getKey();
//                    int qty;
//                    if (bankEvent.bankCacheHashMap.get(itemName) != null) {
//                        qty = grandExchangeItems.getValue().getQty() - bankEvent.bankCacheHashMap.get(itemName).getQty();
//                    } else {
//                        qty = grandExchangeItems.getValue().getQty();
//                    }
//                    int price = grandExchangeItems.getValue().getPrice();
//                    while (!alreadyHaveOffer(itemName)) {
//                        if (GrandExchange.getWindowState().equals(GrandExchange.WINDOW_STATE.OFFER_WINDOW)) {
//                            General.println("We are in offer window");
//                        } else if (GrandExchange.getWindowState().equals(GrandExchange.WINDOW_STATE.SELECTION_WINDOW)) {
//                            General.println("We are in selection window");
//                            if (!getEmptyBox().isPresent()) {
//                                if (GrandExchange.collectItems(GrandExchange.COLLECT_METHOD.NOTES)) {
//                                    Timing.waitCondition(() -> GrandExchange.getOffers().length < 6, 5000);
//                                }
//                            } else if (!alreadyHaveOffer(itemName)) {
//                                General.println("We dont currently have an offer for: " + itemName);
//                                openFirstEmptyBox();
//                            } else if (alreadyHaveOffer(itemName)) {
//                                General.println("We already have an offer for: " + itemName);
//                                break;
//                            }
//                        } else if (GrandExchange.getWindowState().equals(GrandExchange.WINDOW_STATE.NEW_OFFER_WINDOW)) {
//                            General.println("We are in new offer window");
//                            General.println("ItemName: " + itemName);
//                            if (isItemThere(itemName)) {
//                                General.println("Item is there");
//                                General.sleep(1000);
//                            } else if (!isItemThere(itemName)) {
//                                new TypingEvent(script, itemName).setInterruptCondition(() -> isItemThere(itemName)).execute();
//                            }
//                        }
//                    }
//                    General.sleep(1000);
//                }
//            }
//        }
//    }
//
//    public boolean isItemThere(String itemName) {
//        RSInterface itemList = ExchangeBoxes.itemList;
//        if (Interfaces.isInterfaceSubstantiated(itemList)) {
//            for (int i = 0; i < 9; i++) {
//                String itemBoxName = itemList.getChild(i).getComponentName().replace("<col=ff9040>", "").replace("</col>", "");
//                General.println("ItemBoxName: " + i + " " + itemBoxName);
//                if (itemBoxName.equals(itemName)) {
//                    return true;
//                }
//            }
//        }
//        return false;
//    }
//
//
//    public void openFirstEmptyBox() {
//        General.println("Trying to open first empty box");
//        RSInterface emptyBox = getFirstEmptyBox().get();
//        if (emptyBox.getChild(ExchangeBoxes.buyChild).click()) {
//            Timing.waitCondition(() -> GrandExchange.getWindowState().equals(GrandExchange.WINDOW_STATE.NEW_OFFER_WINDOW), 5000);
//        }
//    }
//
//    public boolean alreadyHaveOffer(String itemName) {
//        return Arrays.stream(ExchangeBoxes.allBoxes).anyMatch(i -> i.getChild(19).getText().equals(itemName));
//    }
//
//    public boolean isBoxEmpty(RSInterface box) {
//        return Interfaces.isInterfaceSubstantiated(box.getChild(ExchangeBoxes.buyChild));
//    }
//
//    public Optional<RSInterface> getEmptyBox() {
//        RSInterface[] allBoxes = ExchangeBoxes.allBoxes;
//        int buyChild = ExchangeBoxes.buyChild;
//        return Arrays.stream(allBoxes).filter(i -> Interfaces.isInterfaceSubstantiated(i.getChild(buyChild))).findAny();
//    }
//
//    public Optional<RSInterface> getFirstEmptyBox() {
//        RSInterface[] allBoxes = ExchangeBoxes.allBoxes;
//        int buyChild = ExchangeBoxes.buyChild;
//        return Arrays.stream(allBoxes).filter(i -> Interfaces.isInterfaceSubstantiated(i.getChild(buyChild))).findFirst();
//    }
//
//
//    public boolean needCoins() {
//        return !InventoryEvent.contains("Coins");
//    }
//
//    public void getCoins() throws IOException, InterruptedException {
//        new BankEventV2(script).addReq("Coins", Integer.MAX_VALUE).execute();
//    }
//
//    public boolean canOpenExchange() {
//        return GrandExchange.getWindowState() == null;
//    }
//
//    public void openGrandExchange() {
//        RSNPC[] clerk = NPCs.find(Constants.IDs.NPCs.ge_clerk);
//        RSObject booth = Methods.getObjectWithAction("Exchange", "Grand Exchange booth", 20);
//        if (booth != null) {
//            if (DynamicClicking.clickRSObject(booth, "Exchange")) {
//                Timing.waitCondition(() -> GrandExchange.getWindowState() != null, 5000);
//            }
//        }
//    }
//
//    public RSPlayer me() {
//        return Player.getRSPlayer();
//    }
//
//    public GEEvent addReq(String itemName, int qty, int price) {
//        grandExchangeItemHashMap.put(itemName, new GrandExchangeItem(itemName, qty, price));
//        return this;
//    }
//
//
//}
