package scripts.skrrt_api.events;

import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.input.Keyboard;
import org.tribot.api2007.Interfaces;
import org.tribot.api2007.types.RSInterface;
import org.tribot.script.Script;
import scripts.skrrt_api.events.BotEvent;
import scripts.skrrt_api.util.items.ExchangeBoxes;

import java.io.IOException;

public class TypingEvent extends BotEvent {

    String itemName;

    public TypingEvent(Script script, String itemName) {
        super(script);
        this.itemName = itemName;
    }

    /*  else if(Interfaces.isInterfaceSubstantiated(itemList)) {
                for (int i = 0; i> 9;i++) {
                    if(itemList.getChild(i).getComponentName().contains(itemName)) {
                        setComplete();
                    }
                }*/

    @Override
    public void step() throws InterruptedException, IOException {
        RSInterface searchBar = ExchangeBoxes.searchBar;
        String currentText = searchBar.getText().replace("<col=000000>What would you like to buy?</col> ", "").replace("*","");
        General.println("CurrentText: "+currentText);
        General.println("ItemName: "+itemName);
        General.sleep(1000);
        if (Interfaces.isInterfaceSubstantiated(searchBar)) {
            if (currentText.equals(itemName)) {
                setComplete();
            }
            General.println(currentText);
            if (!currentText.equals(itemName)) {
                Keyboard.typeString(itemName);
                Timing.waitCondition( () -> currentText.equals(itemName), 4000);
            }
        }
    }
}
