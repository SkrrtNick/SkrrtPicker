package scripts.skrrt_api.util.items;

import lombok.Getter;
import org.tribot.api2007.types.RSItemDefinition;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.BooleanSupplier;

public class NewBankItem {
    private int ID;
    private ArrayList<Integer> IDs;
    private int quantity;
    private boolean tradeable;
    private String name;
    private BooleanSupplier conditionMet;

    public NewBankItem(int ID, int quantity) {
        this.ID = ID;
        this.quantity = quantity;
        RSItemDefinition item = RSItemDefinition.get(ID);
        if(item!=null){
            this.name = item.getName();
            this.tradeable = item.isTradeableOnGrandExchange();
        }
        this.conditionMet = ()->true;
    }
    public NewBankItem(ArrayList<Integer> ID, int quantity) {
        this.IDs = ID;
        this.quantity = quantity;
        RSItemDefinition item = RSItemDefinition.get(ID.get(ID.size()-1));
        if(item!=null){
            this.name = item.getName().substring(0,item.getName().length()-3);
        }
        this.tradeable = true;
        this.conditionMet = ()->true;
    }
    public NewBankItem(int ID, int quantity, BooleanSupplier conditionMet) {
        this.ID = ID;
        this.quantity = quantity;
        RSItemDefinition item = RSItemDefinition.get(ID);
        if(item!=null){
            this.name = item.getName();
            this.tradeable = item.isTradeableOnGrandExchange();
        }
        this.conditionMet = conditionMet;
    }
    public NewBankItem(ArrayList<Integer> ID, int quantity, BooleanSupplier conditionMet) {
        this.IDs = ID;
        this.quantity = quantity;
        RSItemDefinition item = RSItemDefinition.get(ID.get(ID.size()-1));
        this.tradeable = true;
        if(item!=null){
            this.name = item.getName().substring(0,item.getName().length()-3);
        }
        this.conditionMet = conditionMet;
    }

    public int getID() {
        return ID;
    }

    public ArrayList<Integer> getIDs() {
        return IDs;
    }

    public int getQuantity() {
        return quantity;
    }

    public int[] getIDsAsInt(){
        return Arrays.stream(IDs.toArray(Integer[]::new)).mapToInt(Integer::intValue).toArray();
    }

    public boolean isTradeable() {
        return tradeable;
    }

    public String getName() {
        return name;
    }

    public BooleanSupplier isConditionMet() {
        return conditionMet;
    }
}
